{{- define "bifrost.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bifrost.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "bifrost.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "bifrost.labels" -}}
helm.sh/chart: {{ include "bifrost.chart" . }}
{{ include "bifrost.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "bifrost.selectorLabels" -}}
app.kubernetes.io/name: {{ include "bifrost.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "bifrost.serverSelectorLabels" -}}
{{ include "bifrost.selectorLabels" . }}
app.kubernetes.io/component: server
{{- end }}

{{- /* Pod topology spread constraints. A constraint that omits labelSelector would count
       no pods at all, so it defaults to this release's server pod selector labels. Only an
       absent key is defaulted: an explicit empty selector ({}) matches every pod in the
       namespace and is kept as written. */ -}}
{{- define "bifrost.topologySpreadConstraints" -}}
{{- $constraints := list }}
{{- range .Values.topologySpreadConstraints }}
{{- $constraint := deepCopy . }}
{{- if not (hasKey $constraint "labelSelector") }}
{{- $_ := set $constraint "labelSelector" (dict "matchLabels" (include "bifrost.serverSelectorLabels" $ | fromYaml)) }}
{{- end }}
{{- $constraints = append $constraints $constraint }}
{{- end }}
{{- toYaml $constraints }}
{{- end }}

{{- /* Init containers for the Bifrost pod, rendered as given. An entry with restartPolicy: Always
       is a Kubernetes native sidecar, which needs Kubernetes 1.29+ (the SidecarContainers feature
       is on by default from 1.29). Older API servers drop or reject the field, which would leave
       the pod stuck behind an init container that never exits, so the chart refuses to render it. */ -}}
{{- define "bifrost.initContainers" -}}
{{- range .Values.initContainers }}
{{- if and (eq (toString .restartPolicy) "Always") (semverCompare "<1.29.0-0" $.Capabilities.KubeVersion.Version) }}
{{- fail (printf "ERROR: native sidecar container '%s' (restartPolicy: Always) needs Kubernetes 1.29 or newer; this cluster reports %s. Use extraContainers for a regular sidecar instead." .name $.Capabilities.KubeVersion.Version) }}
{{- end }}
{{- end }}
{{- with .Values.initContainers }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "bifrost.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "bifrost.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "bifrost.postgresql.host" -}}
{{- if .Values.postgresql.external.enabled }}
{{- .Values.postgresql.external.host }}
{{- else }}
{{- printf "%s-postgresql" (include "bifrost.fullname" .) }}
{{- end }}
{{- end }}

{{- define "bifrost.postgresql.port" -}}
{{- if .Values.postgresql.external.enabled -}}
{{- .Values.postgresql.external.port -}}
{{- else -}}
5432
{{- end -}}
{{- end -}}

{{- define "bifrost.postgresql.database" -}}
{{- if .Values.postgresql.external.enabled }}
{{- .Values.postgresql.external.database }}
{{- else }}
{{- .Values.postgresql.auth.database }}
{{- end }}
{{- end }}

{{- define "bifrost.postgresql.username" -}}
{{- if .Values.postgresql.external.enabled }}
{{- .Values.postgresql.external.user }}
{{- else }}
{{- .Values.postgresql.auth.username }}
{{- end }}
{{- end }}

{{- define "bifrost.postgresql.password" -}}
{{- if .Values.postgresql.external.enabled -}}
{{- if .Values.postgresql.external.existingSecret -}}
env.BIFROST_POSTGRES_PASSWORD
{{- else -}}
{{- .Values.postgresql.external.password -}}
{{- end -}}
{{- else -}}
{{- if .Values.postgresql.auth.existingSecret -}}
env.BIFROST_POSTGRES_PASSWORD
{{- else -}}
{{- .Values.postgresql.auth.password -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.postgresql.sslMode" -}}
{{- if .Values.postgresql.external.enabled -}}
{{- .Values.postgresql.external.sslMode -}}
{{- else -}}
disable
{{- end -}}
{{- end -}}

{{- /*
  Logs-store PostgreSQL helpers. When storage.logsStore.postgres.enabled is true,
  the logs store points at a separate external PostgreSQL; otherwise every helper
  falls back to the shared bifrost.postgresql.* helpers so behavior is unchanged.
*/ -}}
{{- define "bifrost.logsPostgresql.host" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- .Values.storage.logsStore.postgres.host -}}
{{- else -}}
{{- include "bifrost.postgresql.host" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.logsPostgresql.port" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- .Values.storage.logsStore.postgres.port -}}
{{- else -}}
{{- include "bifrost.postgresql.port" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.logsPostgresql.database" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- .Values.storage.logsStore.postgres.database -}}
{{- else -}}
{{- include "bifrost.postgresql.database" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.logsPostgresql.username" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- .Values.storage.logsStore.postgres.user -}}
{{- else -}}
{{- include "bifrost.postgresql.username" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.logsPostgresql.password" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- if .Values.storage.logsStore.postgres.existingSecret -}}
env.BIFROST_LOGS_POSTGRES_PASSWORD
{{- else -}}
{{- .Values.storage.logsStore.postgres.password -}}
{{- end -}}
{{- else -}}
{{- include "bifrost.postgresql.password" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.logsPostgresql.sslMode" -}}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore -}}
{{- .Values.storage.logsStore.postgres.sslMode -}}
{{- else -}}
{{- include "bifrost.postgresql.sslMode" . -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.weaviate.host" -}}
{{- if .Values.vectorStore.weaviate.external.enabled }}
{{- .Values.vectorStore.weaviate.external.host }}
{{- else }}
{{- printf "%s-weaviate" (include "bifrost.fullname" .) }}
{{- end }}
{{- end }}

{{- define "bifrost.weaviate.scheme" -}}
{{- if .Values.vectorStore.weaviate.external.enabled -}}
{{- .Values.vectorStore.weaviate.external.scheme -}}
{{- else -}}
http
{{- end -}}
{{- end -}}

{{- define "bifrost.weaviate.apiKey" -}}
{{- if .Values.vectorStore.weaviate.external.enabled -}}
{{- if .Values.vectorStore.weaviate.external.existingSecret -}}
env.BIFROST_WEAVIATE_API_KEY
{{- else -}}
{{- .Values.vectorStore.weaviate.external.apiKey -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.redis.host" -}}
{{- if .Values.vectorStore.redis.external.enabled }}
{{- .Values.vectorStore.redis.external.host }}
{{- else }}
{{- printf "%s-redis-master" (include "bifrost.fullname" .) }}
{{- end }}
{{- end }}

{{- define "bifrost.redis.port" -}}
{{- if .Values.vectorStore.redis.external.enabled -}}
{{- .Values.vectorStore.redis.external.port -}}
{{- else -}}
6379
{{- end -}}
{{- end -}}

{{- define "bifrost.redis.password" -}}
{{- if .Values.vectorStore.redis.external.enabled -}}
{{- if .Values.vectorStore.redis.external.existingSecret -}}
env.BIFROST_REDIS_PASSWORD
{{- else -}}
{{- .Values.vectorStore.redis.external.password -}}
{{- end -}}
{{- else -}}
{{- .Values.vectorStore.redis.auth.password -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.qdrant.host" -}}
{{- if .Values.vectorStore.qdrant.external.enabled }}
{{- .Values.vectorStore.qdrant.external.host }}
{{- else }}
{{- printf "%s-qdrant" (include "bifrost.fullname" .) }}
{{- end }}
{{- end }}

{{- define "bifrost.qdrant.port" -}}
{{- if .Values.vectorStore.qdrant.external.enabled -}}
{{- .Values.vectorStore.qdrant.external.port -}}
{{- else -}}
6334
{{- end -}}
{{- end -}}

{{- define "bifrost.qdrant.apiKey" -}}
{{- if .Values.vectorStore.qdrant.external.enabled -}}
{{- if .Values.vectorStore.qdrant.external.existingSecret -}}
env.BIFROST_QDRANT_API_KEY
{{- else -}}
{{- .Values.vectorStore.qdrant.external.apiKey -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.pinecone.apiKey" -}}
{{- if .Values.vectorStore.pinecone.external.enabled -}}
{{- if .Values.vectorStore.pinecone.external.existingSecret -}}
env.BIFROST_PINECONE_API_KEY
{{- else -}}
{{- .Values.vectorStore.pinecone.external.apiKey -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "bifrost.qdrant.useTls" -}}
{{- if .Values.vectorStore.qdrant.external.enabled -}}
{{- .Values.vectorStore.qdrant.external.useTls -}}
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "bifrost.config" -}}
{{- $config := dict "$schema" (.Values.bifrost.schemaUrl | default "https://www.getbifrost.ai/schema") }}
{{- if .Values.bifrost.sourceOfTruth }}
{{- $_ := set $config "source_of_truth" .Values.bifrost.sourceOfTruth }}
{{- end }}
{{- if .Values.bifrost.encryptionKey }}
{{- $_ := set $config "encryption_key" .Values.bifrost.encryptionKey }}
{{- end }}
{{- if .Values.bifrost.envLabel }}
{{- $_ := set $config "env_label" .Values.bifrost.envLabel }}
{{- end }}
{{- if .Values.bifrost.setupToken }}
{{- $_ := set $config "setup_token" .Values.bifrost.setupToken }}
{{- end }}
{{- with .Values.bifrost.proxyConfig }}
{{- $proxy := dict "enabled" (.enabled | default false) }}
{{- if .type }}{{- $_ := set $proxy "type" .type }}{{- end }}
{{- if .url }}{{- $_ := set $proxy "url" .url }}{{- end }}
{{- if .username }}{{- $_ := set $proxy "username" .username }}{{- end }}
{{- if .password }}{{- $_ := set $proxy "password" .password }}{{- end }}
{{- if .noProxy }}{{- $_ := set $proxy "no_proxy" .noProxy }}{{- end }}
{{- if hasKey . "timeout" }}{{- $_ := set $proxy "timeout" (.timeout | int) }}{{- end }}
{{- if hasKey . "skipTlsVerify" }}{{- $_ := set $proxy "skip_tls_verify" .skipTlsVerify }}{{- end }}
{{- if hasKey . "enableForScim" }}{{- $_ := set $proxy "enable_for_scim" .enableForScim }}{{- end }}
{{- if hasKey . "enableForInference" }}{{- $_ := set $proxy "enable_for_inference" .enableForInference }}{{- end }}
{{- if hasKey . "enableForApi" }}{{- $_ := set $proxy "enable_for_api" .enableForApi }}{{- end }}
{{- $_ := set $config "proxy_config" $proxy }}
{{- end }}
{{- if .Values.bifrost.client }}
{{- $client := dict }}
{{- if hasKey .Values.bifrost.client "dropExcessRequests" }}
{{- $_ := set $client "drop_excess_requests" .Values.bifrost.client.dropExcessRequests }}
{{- end }}
{{- if .Values.bifrost.client.initialPoolSize }}
{{- $_ := set $client "initial_pool_size" .Values.bifrost.client.initialPoolSize }}
{{- end }}
{{- if .Values.bifrost.client.allowedOrigins }}
{{- $_ := set $client "allowed_origins" .Values.bifrost.client.allowedOrigins }}
{{- end }}
{{- if hasKey .Values.bifrost.client "enableLogging" }}
{{- $_ := set $client "enable_logging" .Values.bifrost.client.enableLogging }}
{{- end }}
{{- if hasKey .Values.bifrost.client "enforceAuthOnInference" }}
{{- $_ := set $client "enforce_auth_on_inference" .Values.bifrost.client.enforceAuthOnInference }}
{{- end }}
{{- if .Values.bifrost.client.dualCredentialConflictBehavior }}
{{- $_ := set $client "dual_credential_conflict_behavior" .Values.bifrost.client.dualCredentialConflictBehavior }}
{{- end }}
{{- if .Values.bifrost.client.extraFieldsPlacement }}
{{- $_ := set $client "extra_fields_placement" .Values.bifrost.client.extraFieldsPlacement }}
{{- end }}
{{- if hasKey .Values.bifrost.client "enforceGovernanceHeader" }}
{{- $_ := set $client "enforce_governance_header" .Values.bifrost.client.enforceGovernanceHeader }}
{{- end }}
{{- if .Values.bifrost.client.maxRequestBodySizeMb }}
{{- $_ := set $client "max_request_body_size_mb" .Values.bifrost.client.maxRequestBodySizeMb }}
{{- end }}
{{- if .Values.bifrost.client.compat }}
{{- $compat := dict }}
{{- if hasKey .Values.bifrost.client.compat "convertTextToChat" }}
{{- $_ := set $compat "convert_text_to_chat" .Values.bifrost.client.compat.convertTextToChat }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "convertChatToResponses" }}
{{- $_ := set $compat "convert_chat_to_responses" .Values.bifrost.client.compat.convertChatToResponses }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "shouldDropParams" }}
{{- $_ := set $compat "should_drop_params" .Values.bifrost.client.compat.shouldDropParams }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "shouldConvertParams" }}
{{- $_ := set $compat "should_convert_params" .Values.bifrost.client.compat.shouldConvertParams }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "azureDeepseek" }}
{{- $_ := set $compat "azure_deepseek" .Values.bifrost.client.compat.azureDeepseek }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "forceReasoningOnlyModelsToResponses" }}
{{- $_ := set $compat "force_reasoning_only_models_to_responses" .Values.bifrost.client.compat.forceReasoningOnlyModelsToResponses }}
{{- end }}
{{- if hasKey .Values.bifrost.client.compat "convertDecisionToResponses" }}
{{- $_ := set $compat "convert_decision_to_responses" .Values.bifrost.client.compat.convertDecisionToResponses }}
{{- end }}
{{- $_ := set $client "compat" $compat }}
{{- end }}
{{- if .Values.bifrost.client.prometheusLabels }}
{{- $_ := set $client "prometheus_labels" .Values.bifrost.client.prometheusLabels }}
{{- end }}
{{- if hasKey .Values.bifrost.client "disableContentLogging" }}
{{- $_ := set $client "disable_content_logging" .Values.bifrost.client.disableContentLogging }}
{{- end }}
{{- if hasKey .Values.bifrost.client "retainContentInObjectStorage" }}
{{- $_ := set $client "retain_content_in_object_storage" .Values.bifrost.client.retainContentInObjectStorage }}
{{- end }}
{{- if hasKey .Values.bifrost.client "allowPerRequestContentStorageOverride" }}
{{- $_ := set $client "allow_per_request_content_storage_override" .Values.bifrost.client.allowPerRequestContentStorageOverride }}
{{- end }}
{{- if hasKey .Values.bifrost.client "allowPerRequestRawOverride" }}
{{- $_ := set $client "allow_per_request_raw_override" .Values.bifrost.client.allowPerRequestRawOverride }}
{{- end }}
{{- if .Values.bifrost.client.logRetentionDays }}
{{- $_ := set $client "log_retention_days" .Values.bifrost.client.logRetentionDays }}
{{- end }}
{{- if hasKey .Values.bifrost.client "disableDbPingsInHealth" }}
{{- $_ := set $client "disable_db_pings_in_health" .Values.bifrost.client.disableDbPingsInHealth }}
{{- end }}
{{- if hasKey .Values.bifrost.client "dumpErrorsInConsoleLogs" }}
{{- $_ := set $client "dump_errors_in_console_logs" .Values.bifrost.client.dumpErrorsInConsoleLogs }}
{{- end }}
{{- if .Values.bifrost.client.webhookConfig }}
{{- $webhookConfig := dict }}
{{- if .Values.bifrost.client.webhookConfig.deliveryHistoryRetentionDays }}
{{- $_ := set $webhookConfig "delivery_history_retention_days" .Values.bifrost.client.webhookConfig.deliveryHistoryRetentionDays }}
{{- end }}
{{- $_ := set $client "webhook_config" $webhookConfig }}
{{- end }}
{{- if .Values.bifrost.client.headerFilterConfig }}
{{- $headerFilter := dict }}
{{- if .Values.bifrost.client.headerFilterConfig.allowlist }}
{{- $_ := set $headerFilter "allowlist" .Values.bifrost.client.headerFilterConfig.allowlist }}
{{- end }}
{{- if .Values.bifrost.client.headerFilterConfig.denylist }}
{{- $_ := set $headerFilter "denylist" .Values.bifrost.client.headerFilterConfig.denylist }}
{{- end }}
{{- if or $headerFilter.allowlist $headerFilter.denylist }}
{{- $_ := set $client "header_filter_config" $headerFilter }}
{{- end }}
{{- end }}
{{- if .Values.bifrost.client.asyncJobResultTTL }}
{{- $_ := set $client "async_job_result_ttl" .Values.bifrost.client.asyncJobResultTTL }}
{{- end }}
{{- if .Values.bifrost.client.requiredHeaders }}
{{- $_ := set $client "required_headers" .Values.bifrost.client.requiredHeaders }}
{{- end }}
{{- if .Values.bifrost.client.loggingHeaders }}
{{- $_ := set $client "logging_headers" .Values.bifrost.client.loggingHeaders }}
{{- end }}
{{- if .Values.storage.logsStore.hiddenRequestTypes }}
{{- $_ := set $client "hidden_request_types" .Values.storage.logsStore.hiddenRequestTypes }}
{{- end }}
{{- if .Values.bifrost.client.whitelistedRoutes }}
{{- $_ := set $client "whitelisted_routes" .Values.bifrost.client.whitelistedRoutes }}
{{- end }}
{{- if .Values.bifrost.client.allowedHeaders }}
{{- $_ := set $client "allowed_headers" .Values.bifrost.client.allowedHeaders }}
{{- end }}
{{- if .Values.bifrost.client.mcpAgentDepth }}
{{- $_ := set $client "mcp_agent_depth" .Values.bifrost.client.mcpAgentDepth }}
{{- end }}
{{- if .Values.bifrost.client.mcpToolExecutionTimeout }}
{{- $_ := set $client "mcp_tool_execution_timeout" .Values.bifrost.client.mcpToolExecutionTimeout }}
{{- end }}
{{- if .Values.bifrost.client.mcpCodeModeBindingLevel }}
{{- $_ := set $client "mcp_code_mode_binding_level" .Values.bifrost.client.mcpCodeModeBindingLevel }}
{{- end }}
{{- if hasKey .Values.bifrost.client "mcpToolSyncInterval" }}
{{- $_ := set $client "mcp_tool_sync_interval" .Values.bifrost.client.mcpToolSyncInterval }}
{{- end }}
{{- if hasKey .Values.bifrost.client "hideDeletedVirtualKeysInFilters" }}
{{- $_ := set $client "hide_deleted_virtual_keys_in_filters" .Values.bifrost.client.hideDeletedVirtualKeysInFilters }}
{{- end }}
{{- if hasKey .Values.bifrost.client "deleteExpiredVirtualKeys" }}
{{- $_ := set $client "delete_expired_virtual_keys" .Values.bifrost.client.deleteExpiredVirtualKeys }}
{{- end }}
{{- if hasKey .Values.bifrost.client "vkRotationCooldown" }}
{{- $_ := set $client "vk_rotation_cooldown" .Values.bifrost.client.vkRotationCooldown }}
{{- end }}
{{- if hasKey .Values.bifrost.client "mcpDisableAutoToolInject" }}
{{- $_ := set $client "mcp_disable_auto_tool_inject" .Values.bifrost.client.mcpDisableAutoToolInject }}
{{- end }}
{{- if hasKey .Values.bifrost.client "mcpEnableTempTokenAuth" }}
{{- $_ := set $client "mcp_enable_temp_token_auth" .Values.bifrost.client.mcpEnableTempTokenAuth }}
{{- end }}
{{- if .Values.bifrost.client.routingChainMaxDepth }}
{{- $_ := set $client "routing_chain_max_depth" .Values.bifrost.client.routingChainMaxDepth }}
{{- end }}
{{- if hasKey .Values.bifrost.client "allowDirectKeys" }}
{{- $_ := set $client "allow_direct_keys" .Values.bifrost.client.allowDirectKeys }}
{{- end }}
{{- if .Values.bifrost.client.mcpExternalClientUrl }}
{{- $_ := set $client "mcp_external_client_url" .Values.bifrost.client.mcpExternalClientUrl }}
{{- end }}
{{- if hasKey .Values.bifrost.client "skillsExternalClientUrl" }}
{{- $_ := set $client "skills_external_client_url" .Values.bifrost.client.skillsExternalClientUrl }}
{{- end }}
{{- if hasKey .Values.bifrost.client "a2aPrivateAllowlist" }}
{{- $_ := set $client "a2a_private_allowlist" .Values.bifrost.client.a2aPrivateAllowlist }}
{{- end }}
{{- if hasKey .Values.bifrost.client "a2aExternalClientUrl" }}
{{- $_ := set $client "a2a_external_client_url" .Values.bifrost.client.a2aExternalClientUrl }}
{{- end }}
{{- if .Values.bifrost.client.mcpServerAuthMode }}
{{- if or (eq .Values.bifrost.client.mcpServerAuthMode "oauth") (eq .Values.bifrost.client.mcpServerAuthMode "both") }}
{{- $issuerSet := false }}
{{- if .Values.bifrost.client.oauth2ServerConfig }}{{- if .Values.bifrost.client.oauth2ServerConfig.issuerUrl }}{{- $issuerSet = true }}{{- end }}{{- end }}
{{- if not $issuerSet }}{{- fail (printf "ERROR: bifrost.client.oauth2ServerConfig.issuerUrl is required when bifrost.client.mcpServerAuthMode is '%s'. Bifrost exits at startup without it. Set the issuer URL (env.VAR_NAME is supported) or use mcpServerAuthMode 'headers'." .Values.bifrost.client.mcpServerAuthMode) }}{{- end }}
{{- end }}
{{- $_ := set $client "mcp_server_auth_mode" .Values.bifrost.client.mcpServerAuthMode }}
{{- end }}
{{- if .Values.bifrost.client.oauth2ServerConfig }}
{{- $oauth2 := dict }}
{{- with .Values.bifrost.client.oauth2ServerConfig.issuerUrl }}{{- $_ := set $oauth2 "issuer_url" . }}{{- end }}
{{- with .Values.bifrost.client.oauth2ServerConfig.authCodeTtl }}{{- $_ := set $oauth2 "auth_code_ttl" (. | int) }}{{- end }}
{{- with .Values.bifrost.client.oauth2ServerConfig.accessTokenTtl }}{{- $_ := set $oauth2 "access_token_ttl" (. | int) }}{{- end }}
{{- if hasKey .Values.bifrost.client.oauth2ServerConfig "disableVkIdentity" }}{{- $_ := set $oauth2 "disable_vk_identity" .Values.bifrost.client.oauth2ServerConfig.disableVkIdentity }}{{- end }}
{{- if hasKey .Values.bifrost.client.oauth2ServerConfig "allowedRedirectUris" }}{{- $_ := set $oauth2 "allowed_redirect_uris" (default (list) .Values.bifrost.client.oauth2ServerConfig.allowedRedirectUris) }}{{- end }}
{{- if $oauth2 }}{{- $_ := set $client "oauth2_server_config" $oauth2 }}{{- end }}
{{- end }}
{{- $_ := set $config "client" $client }}
{{- end }}
{{- /* Server */ -}}
{{- if .Values.bifrost.server }}
{{- $server := dict }}
{{- if .Values.bifrost.server.readBufferSize }}
{{- $_ := set $server "read_buffer_size" .Values.bifrost.server.readBufferSize }}
{{- end }}
{{- if not (kindIs "invalid" .Values.bifrost.server.bodyBufferPoolLimitBytes) }}
{{- $_ := set $server "body_buffer_pool_limit_bytes" .Values.bifrost.server.bodyBufferPoolLimitBytes }}
{{- end }}
{{- if .Values.bifrost.server.pluginDownloadPrivateAllowlist }}
{{- $_ := set $server "plugin_download_private_allowlist" .Values.bifrost.server.pluginDownloadPrivateAllowlist }}
{{- end }}
{{- if .Values.bifrost.server.a2aGrpcBaseDomain }}
{{- $_ := set $server "a2a_grpc_base_domain" .Values.bifrost.server.a2aGrpcBaseDomain }}
{{- end }}
{{- if .Values.bifrost.server.a2aGrpcPort }}
{{- $_ := set $server "a2a_grpc_port" (.Values.bifrost.server.a2aGrpcPort | int) }}
{{- end }}
{{- if .Values.bifrost.server.a2aAllowPrivatePushCallbacks }}
{{- $_ := set $server "a2a_allow_private_push_callbacks" true }}
{{- end }}
{{- if $server }}
{{- $_ := set $config "server" $server }}
{{- end }}
{{- end }}
{{- /* Framework */ -}}
{{- if .Values.bifrost.framework }}
{{- $framework := dict }}
{{- if .Values.bifrost.framework.pricing }}
{{- $pricing := dict }}
{{- if .Values.bifrost.framework.pricing.pricingUrl }}
{{- $_ := set $pricing "pricing_url" .Values.bifrost.framework.pricing.pricingUrl }}
{{- end }}
{{- if .Values.bifrost.framework.pricing.modelParametersUrl }}
{{- $_ := set $pricing "model_parameters_url" .Values.bifrost.framework.pricing.modelParametersUrl }}
{{- end }}
{{- if .Values.bifrost.framework.pricing.pricingSyncInterval }}
{{- $_ := set $pricing "pricing_sync_interval" .Values.bifrost.framework.pricing.pricingSyncInterval }}
{{- end }}
{{- if .Values.bifrost.framework.pricing.mcpLibraryUrl }}
{{- $_ := set $pricing "mcp_library_url" .Values.bifrost.framework.pricing.mcpLibraryUrl }}
{{- end }}
{{- /* nil-aware: 0 is a meaningful value here (disables the catalog sync) */ -}}
{{- if not (kindIs "invalid" .Values.bifrost.framework.pricing.mcpLibrarySyncInterval) }}
{{- $_ := set $pricing "mcp_library_sync_interval" .Values.bifrost.framework.pricing.mcpLibrarySyncInterval }}
{{- end }}
{{- /* nil-aware: 0 is a meaningful value here (disables the background refresh) */ -}}
{{- if not (kindIs "invalid" .Values.bifrost.framework.pricing.liveModelsSyncInterval) }}
{{- $_ := set $pricing "live_models_sync_interval" .Values.bifrost.framework.pricing.liveModelsSyncInterval }}
{{- end }}
{{- if or $pricing.pricing_url $pricing.model_parameters_url $pricing.pricing_sync_interval $pricing.mcp_library_url (hasKey $pricing "mcp_library_sync_interval") (hasKey $pricing "live_models_sync_interval") }}
{{- $_ := set $framework "pricing" $pricing }}
{{- end }}
{{- end }}
{{- if $framework }}
{{- $_ := set $config "framework" $framework }}
{{- end }}
{{- end }}
{{- if .Values.bifrost.providers }}
{{- $providers := dict }}
{{- range $providerName, $providerConfig := .Values.bifrost.providers }}
{{- $providerCopy := deepCopy $providerConfig }}
{{- if $providerConfig.network_config }}
{{- $networkConfig := dict }}
{{- if $providerConfig.network_config.base_url }}
{{- $_ := set $networkConfig "base_url" $providerConfig.network_config.base_url }}
{{- end }}
{{- if $providerConfig.network_config.extra_headers }}
{{- $_ := set $networkConfig "extra_headers" $providerConfig.network_config.extra_headers }}
{{- end }}
{{- if hasKey $providerConfig.network_config "default_request_timeout_in_seconds" }}
{{- $_ := set $networkConfig "default_request_timeout_in_seconds" $providerConfig.network_config.default_request_timeout_in_seconds }}
{{- end }}
{{- if hasKey $providerConfig.network_config "max_retries" }}
{{- $_ := set $networkConfig "max_retries" $providerConfig.network_config.max_retries }}
{{- end }}
{{- if hasKey $providerConfig.network_config "retry_backoff_initial" }}
{{- $_ := set $networkConfig "retry_backoff_initial" $providerConfig.network_config.retry_backoff_initial }}
{{- end }}
{{- if hasKey $providerConfig.network_config "retry_backoff_initial_ms" }}
{{- $_ := set $networkConfig "retry_backoff_initial" $providerConfig.network_config.retry_backoff_initial_ms }}
{{- end }}
{{- if hasKey $providerConfig.network_config "retry_backoff_max" }}
{{- $_ := set $networkConfig "retry_backoff_max" $providerConfig.network_config.retry_backoff_max }}
{{- end }}
{{- if hasKey $providerConfig.network_config "retry_backoff_max_ms" }}
{{- $_ := set $networkConfig "retry_backoff_max" $providerConfig.network_config.retry_backoff_max_ms }}
{{- end }}
{{- if hasKey $providerConfig.network_config "insecure_skip_verify" }}
{{- $_ := set $networkConfig "insecure_skip_verify" $providerConfig.network_config.insecure_skip_verify }}
{{- end }}
{{- if hasKey $providerConfig.network_config "ca_cert_pem" }}
{{- $_ := set $networkConfig "ca_cert_pem" $providerConfig.network_config.ca_cert_pem }}
{{- end }}
{{- if hasKey $providerConfig.network_config "stream_idle_timeout_in_seconds" }}
{{- $_ := set $networkConfig "stream_idle_timeout_in_seconds" $providerConfig.network_config.stream_idle_timeout_in_seconds }}
{{- end }}
{{- if hasKey $providerConfig.network_config "keep_alive_timeout_in_seconds" }}
{{- $_ := set $networkConfig "keep_alive_timeout_in_seconds" $providerConfig.network_config.keep_alive_timeout_in_seconds }}
{{- end }}
{{- if hasKey $providerConfig.network_config "max_conns_per_host" }}
{{- $_ := set $networkConfig "max_conns_per_host" $providerConfig.network_config.max_conns_per_host }}
{{- end }}
{{- if hasKey $providerConfig.network_config "enforce_http2" }}
{{- $_ := set $networkConfig "enforce_http2" $providerConfig.network_config.enforce_http2 }}
{{- end }}
{{- if hasKey $providerConfig.network_config "http2_ping_interval_in_seconds" }}
{{- $_ := set $networkConfig "http2_ping_interval_in_seconds" $providerConfig.network_config.http2_ping_interval_in_seconds }}
{{- end }}
{{- if $providerConfig.network_config.beta_header_overrides }}
{{- $_ := set $networkConfig "beta_header_overrides" $providerConfig.network_config.beta_header_overrides }}
{{- end }}
{{- if hasKey $providerConfig.network_config "allow_private_network" }}
{{- $_ := set $networkConfig "allow_private_network" $providerConfig.network_config.allow_private_network }}
{{- end }}
{{- $_ := set $providerCopy "network_config" $networkConfig }}
{{- end }}
{{- if $providerConfig.keys }}
{{- $keys := list }}
{{- range $key := $providerConfig.keys }}
{{- $keyCopy := deepCopy $key }}
{{- if and (not (hasKey $keyCopy "id")) (hasKey $keyCopy "name") $keyCopy.name }}
{{- $_ := set $keyCopy "id" $keyCopy.name }}
{{- end }}
{{- if not (hasKey $keyCopy "weight") }}
{{- $_ := set $keyCopy "weight" 1 }}
{{- end }}
{{- $keys = append $keys $keyCopy }}
{{- end }}
{{- $_ := set $providerCopy "keys" $keys }}
{{- end }}
{{- $_ := set $providers $providerName $providerCopy }}
{{- end }}
{{- $_ := set $config "providers" $providers }}
{{- end }}
{{- /* Governance */ -}}
{{- if .Values.bifrost.governance }}
{{- $governance := dict }}
{{- if .Values.bifrost.governance.budgets }}
{{- $_ := set $governance "budgets" .Values.bifrost.governance.budgets }}
{{- end }}
{{- if .Values.bifrost.governance.rateLimits }}
{{- $rateLimits := list }}
{{- range .Values.bifrost.governance.rateLimits }}
{{- $rl := dict "id" .id }}
{{- if .token_max_limit }}{{- $_ := set $rl "token_max_limit" .token_max_limit }}{{- end }}
{{- if .token_reset_duration }}{{- $_ := set $rl "token_reset_duration" .token_reset_duration }}{{- end }}
{{- if .request_max_limit }}{{- $_ := set $rl "request_max_limit" .request_max_limit }}{{- end }}
{{- if .request_reset_duration }}{{- $_ := set $rl "request_reset_duration" .request_reset_duration }}{{- end }}
{{- $rateLimits = append $rateLimits $rl }}
{{- end }}
{{- $_ := set $governance "rate_limits" $rateLimits }}
{{- end }}
{{- if .Values.bifrost.governance.customers }}
{{- $_ := set $governance "customers" .Values.bifrost.governance.customers }}
{{- end }}
{{- if .Values.bifrost.governance.teams }}
{{- $_ := set $governance "teams" .Values.bifrost.governance.teams }}
{{- end }}
{{- if .Values.bifrost.governance.businessUnits }}
{{- $businessUnits := list }}
{{- range .Values.bifrost.governance.businessUnits }}
{{- $bu := dict "id" .id "name" .name }}
{{- if .budget_id }}{{- $_ := set $bu "budget_id" .budget_id }}{{- end }}
{{- if .rate_limit_id }}{{- $_ := set $bu "rate_limit_id" .rate_limit_id }}{{- end }}
{{- if .profile }}{{- $_ := set $bu "profile" .profile }}{{- end }}
{{- if .config }}{{- $_ := set $bu "config" .config }}{{- end }}
{{- if .claims }}{{- $_ := set $bu "claims" .claims }}{{- end }}
{{- if .access_profile }}{{- $_ := set $bu "access_profile" .access_profile }}{{- end }}
{{- if .teamIds }}{{- $_ := set $bu "team_ids" .teamIds }}{{- end }}
{{- $businessUnits = append $businessUnits $bu }}
{{- end }}
{{- $_ := set $governance "business_units" $businessUnits }}
{{- end }}
{{- if .Values.bifrost.governance.roles }}
{{- $roles := list }}
{{- range .Values.bifrost.governance.roles }}
{{- $role := dict "name" .name }}
{{- if .description }}{{- $_ := set $role "description" .description }}{{- end }}
{{- if .dac }}{{- $_ := set $role "dac" .dac }}{{- end }}
{{- if .entity_dac }}{{- $_ := set $role "entity_dac" .entity_dac }}{{- end }}
{{- if hasKey . "access_profiles" }}
{{- $_ := set $role "access_profiles" .access_profiles }}
{{- else if .access_profile }}
{{- $_ := set $role "access_profile" .access_profile }}
{{- end }}
{{- if .permissions }}{{- $_ := set $role "permissions" .permissions }}{{- end }}
{{- $roles = append $roles $role }}
{{- end }}
{{- $_ := set $governance "roles" $roles }}
{{- end }}
{{- if .Values.bifrost.governance.virtualKeys }}
{{- $vks := list }}
{{- range .Values.bifrost.governance.virtualKeys }}
{{- $vk := dict "id" .id "name" .name }}
{{- if .value }}{{- $_ := set $vk "value" .value }}{{- end }}
{{- if .description }}{{- $_ := set $vk "description" .description }}{{- end }}
{{- if hasKey . "is_active" }}{{- $_ := set $vk "is_active" .is_active }}{{- end }}
{{- if .expires_at }}{{- $_ := set $vk "expires_at" .expires_at }}{{- end }}
{{- if hasKey . "delete_after_expire" }}{{- $_ := set $vk "delete_after_expire" .delete_after_expire }}{{- end }}
{{- if hasKey . "disable_content_logging" }}{{- $_ := set $vk "disable_content_logging" .disable_content_logging }}{{- end }}
{{- if hasKey . "metadata" }}{{- $_ := set $vk "metadata" .metadata }}{{- end }}
{{- if .team_id }}{{- $_ := set $vk "team_id" .team_id }}{{- end }}
{{- if .customer_id }}{{- $_ := set $vk "customer_id" .customer_id }}{{- end }}
{{- if .business_unit_id }}{{- $_ := set $vk "business_unit_id" .business_unit_id }}{{- end }}
{{- if hasKey . "access_profile_id" }}{{- $_ := set $vk "access_profile_id" .access_profile_id }}{{- end }}
{{- if .rate_limit_id }}{{- $_ := set $vk "rate_limit_id" .rate_limit_id }}{{- end }}
{{- if hasKey . "calendar_aligned" }}{{- $_ := set $vk "calendar_aligned" .calendar_aligned }}{{- end }}
{{- if hasKey . "allow_all_providers" }}{{- $_ := set $vk "allow_all_providers" .allow_all_providers }}{{- end }}
{{- if .provider_configs }}{{- $_ := set $vk "provider_configs" .provider_configs }}{{- end }}
{{- if .mcp_configs }}{{- $_ := set $vk "mcp_configs" .mcp_configs }}{{- end }}
{{- $vks = append $vks $vk }}
{{- end }}
{{- $_ := set $governance "virtual_keys" $vks }}
{{- end }}
{{- if hasKey .Values.bifrost.governance "projects" }}
{{- $_ := set $governance "projects" (default (list) .Values.bifrost.governance.projects) }}
{{- end }}
{{- if .Values.bifrost.governance.routingRules }}
{{- $_ := set $governance "routing_rules" .Values.bifrost.governance.routingRules }}
{{- end }}
{{- if .Values.bifrost.governance.modelConfigs }}
{{- $_ := set $governance "model_configs" .Values.bifrost.governance.modelConfigs }}
{{- end }}
{{- if .Values.bifrost.governance.providers }}
{{- $_ := set $governance "providers" .Values.bifrost.governance.providers }}
{{- end }}
{{- if .Values.bifrost.governance.pricingOverrides }}
{{- $_ := set $governance "pricing_overrides" .Values.bifrost.governance.pricingOverrides }}
{{- end }}
{{- if .Values.bifrost.governance.complexityAnalyzerConfig }}
{{- $_ := set $governance "complexity_analyzer_config" .Values.bifrost.governance.complexityAnalyzerConfig }}
{{- end }}
{{- if .Values.bifrost.governance.authConfig }}
{{- $authConfig := dict }}
{{- if and .Values.bifrost.governance.authConfig.existingSecret .Values.bifrost.governance.authConfig.usernameKey }}
{{- $_ := set $authConfig "admin_username" "env.BIFROST_ADMIN_USERNAME" }}
{{- else if .Values.bifrost.governance.authConfig.adminUsername }}
{{- $_ := set $authConfig "admin_username" .Values.bifrost.governance.authConfig.adminUsername }}
{{- end }}
{{- if and .Values.bifrost.governance.authConfig.existingSecret .Values.bifrost.governance.authConfig.passwordKey }}
{{- $_ := set $authConfig "admin_password" "env.BIFROST_ADMIN_PASSWORD" }}
{{- else if .Values.bifrost.governance.authConfig.adminPassword }}
{{- $_ := set $authConfig "admin_password" .Values.bifrost.governance.authConfig.adminPassword }}
{{- end }}
{{- if hasKey .Values.bifrost.governance.authConfig "isEnabled" }}
{{- $_ := set $authConfig "is_enabled" .Values.bifrost.governance.authConfig.isEnabled }}
{{- end }}
{{- if hasKey .Values.bifrost.governance.authConfig "disableAuthOnInference" }}
{{- $_ := set $authConfig "disable_auth_on_inference" .Values.bifrost.governance.authConfig.disableAuthOnInference }}
{{- end }}
{{- if or $authConfig.admin_username $authConfig.admin_password $authConfig.is_enabled $authConfig.disable_auth_on_inference }}
{{- $_ := set $governance "auth_config" $authConfig }}
{{- end }}
{{- end }}
{{- if or $governance.budgets $governance.rate_limits $governance.customers $governance.teams $governance.business_units $governance.roles $governance.virtual_keys (hasKey $governance "projects") $governance.routing_rules $governance.model_configs $governance.providers $governance.pricing_overrides $governance.complexity_analyzer_config $governance.auth_config }}
{{- $_ := set $config "governance" $governance }}
{{- end }}
{{- end }}
{{- /* Top-level Auth Config - for main Bifrost authentication */ -}}
{{- if .Values.bifrost.authConfig }}
{{- $authConfig := dict }}
{{- /* Only use env var reference if governance auth secret is NOT already configured (to avoid referencing uninjected env vars) */ -}}
{{- if and .Values.bifrost.authConfig.existingSecret .Values.bifrost.authConfig.usernameKey (not (and .Values.bifrost.governance .Values.bifrost.governance.authConfig .Values.bifrost.governance.authConfig.existingSecret)) }}
{{- $_ := set $authConfig "admin_username" "env.BIFROST_ADMIN_USERNAME" }}
{{- else if .Values.bifrost.authConfig.adminUsername }}
{{- $_ := set $authConfig "admin_username" .Values.bifrost.authConfig.adminUsername }}
{{- end }}
{{- if and .Values.bifrost.authConfig.existingSecret .Values.bifrost.authConfig.passwordKey (not (and .Values.bifrost.governance .Values.bifrost.governance.authConfig .Values.bifrost.governance.authConfig.existingSecret)) }}
{{- $_ := set $authConfig "admin_password" "env.BIFROST_ADMIN_PASSWORD" }}
{{- else if .Values.bifrost.authConfig.adminPassword }}
{{- $_ := set $authConfig "admin_password" .Values.bifrost.authConfig.adminPassword }}
{{- end }}
{{- if hasKey .Values.bifrost.authConfig "isEnabled" }}
{{- $_ := set $authConfig "is_enabled" .Values.bifrost.authConfig.isEnabled }}
{{- end }}
{{- if hasKey .Values.bifrost.authConfig "disableAuthOnInference" }}
{{- $_ := set $authConfig "disable_auth_on_inference" .Values.bifrost.authConfig.disableAuthOnInference }}
{{- end }}
{{- if or $authConfig.admin_username $authConfig.admin_password $authConfig.is_enabled $authConfig.disable_auth_on_inference }}
{{- $_ := set $config "auth_config" $authConfig }}
{{- end }}
{{- end }}
{{- /* Cluster Config */ -}}
{{- if and .Values.bifrost.cluster .Values.bifrost.cluster.enabled }}
{{- $cluster := dict "enabled" true }}
{{- $clusterType := default "mesh" .Values.bifrost.cluster.type }}
{{- $_ := set $cluster "type" $clusterType }}
{{- if .Values.bifrost.cluster.region }}
{{- $_ := set $cluster "region" .Values.bifrost.cluster.region }}
{{- end }}
{{- if eq $clusterType "broker" }}
{{- $broker := dict }}
{{- $_ := set $broker "address" .Values.bifrost.cluster.broker.address }}
{{- if .Values.bifrost.cluster.broker.listenPort }}
{{- $_ := set $broker "listen_port" .Values.bifrost.cluster.broker.listenPort }}
{{- end }}
{{- if hasKey .Values.bifrost.cluster.broker "tls" }}
{{- $_ := set $broker "tls" .Values.bifrost.cluster.broker.tls }}
{{- end }}
{{- if .Values.bifrost.cluster.broker.authToken }}
{{- $_ := set $broker "auth_token" .Values.bifrost.cluster.broker.authToken }}
{{- end }}
{{- $_ := set $cluster "broker" $broker }}
{{- else }}
{{- if .Values.bifrost.cluster.peers }}
{{- $_ := set $cluster "peers" .Values.bifrost.cluster.peers }}
{{- end }}
{{- if .Values.bifrost.cluster.gossip }}
{{- $gossip := dict }}
{{- if .Values.bifrost.cluster.gossip.port }}
{{- $_ := set $gossip "port" .Values.bifrost.cluster.gossip.port }}
{{- end }}
{{- if .Values.bifrost.cluster.gossip.config }}
{{- $gossipConfig := dict }}
{{- if .Values.bifrost.cluster.gossip.config.timeoutSeconds }}
{{- $_ := set $gossipConfig "timeout_seconds" .Values.bifrost.cluster.gossip.config.timeoutSeconds }}
{{- end }}
{{- if .Values.bifrost.cluster.gossip.config.successThreshold }}
{{- $_ := set $gossipConfig "success_threshold" .Values.bifrost.cluster.gossip.config.successThreshold }}
{{- end }}
{{- if .Values.bifrost.cluster.gossip.config.failureThreshold }}
{{- $_ := set $gossipConfig "failure_threshold" .Values.bifrost.cluster.gossip.config.failureThreshold }}
{{- end }}
{{- $_ := set $gossip "config" $gossipConfig }}
{{- end }}
{{- $_ := set $cluster "gossip" $gossip }}
{{- end }}
{{- if .Values.bifrost.cluster.grpc }}
{{- $grpc := dict }}
{{- if .Values.bifrost.cluster.grpc.port }}
{{- $_ := set $grpc "port" .Values.bifrost.cluster.grpc.port }}
{{- end }}
{{- if .Values.bifrost.cluster.grpc.dialTimeoutSeconds }}
{{- $_ := set $grpc "dial_timeout_seconds" .Values.bifrost.cluster.grpc.dialTimeoutSeconds }}
{{- end }}
{{- if $grpc }}
{{- $_ := set $cluster "grpc" $grpc }}
{{- end }}
{{- end }}
{{- if and .Values.bifrost.cluster.discovery .Values.bifrost.cluster.discovery.enabled }}
{{- $discovery := dict "enabled" true "type" .Values.bifrost.cluster.discovery.type }}
{{- $serviceName := .Values.bifrost.cluster.discovery.serviceName }}
{{- if and (not $serviceName) (or (eq .Values.bifrost.cluster.discovery.type "consul") (eq .Values.bifrost.cluster.discovery.type "etcd") (eq .Values.bifrost.cluster.discovery.type "udp")) }}
{{- fail "ERROR: bifrost.cluster.discovery.serviceName is required for consul/etcd/udp discovery." }}
{{- end }}
{{- if $serviceName }}
{{- $_ := set $discovery "service_name" $serviceName }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.bindPort }}
{{- $_ := set $discovery "bind_port" .Values.bifrost.cluster.discovery.bindPort }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.dialTimeout }}
{{- $_ := set $discovery "dial_timeout" .Values.bifrost.cluster.discovery.dialTimeout }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.allowedAddressSpace }}
{{- $_ := set $discovery "allowed_address_space" .Values.bifrost.cluster.discovery.allowedAddressSpace }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.k8sNamespace }}
{{- $_ := set $discovery "k8s_namespace" .Values.bifrost.cluster.discovery.k8sNamespace }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.k8sLabelSelector }}
{{- $_ := set $discovery "k8s_label_selector" .Values.bifrost.cluster.discovery.k8sLabelSelector }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.dnsNames }}
{{- $_ := set $discovery "dns_names" .Values.bifrost.cluster.discovery.dnsNames }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.udpBroadcastPort }}
{{- $_ := set $discovery "udp_broadcast_port" .Values.bifrost.cluster.discovery.udpBroadcastPort }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.consulAddress }}
{{- $_ := set $discovery "consul_address" .Values.bifrost.cluster.discovery.consulAddress }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.etcdEndpoints }}
{{- $_ := set $discovery "etcd_endpoints" .Values.bifrost.cluster.discovery.etcdEndpoints }}
{{- end }}
{{- if .Values.bifrost.cluster.discovery.mdnsService }}
{{- $_ := set $discovery "mdns_service" .Values.bifrost.cluster.discovery.mdnsService }}
{{- end }}
{{- $_ := set $cluster "discovery" $discovery }}
{{- end }}
{{- end }}
{{- $_ := set $config "cluster_config" $cluster }}
{{- end }}
{{- /* SCIM Config */ -}}
{{- /* Rendered whenever bifrost.scim is declared at all — including enabled: false. Helm then
       owns the section and a disable actually propagates; omitting scim_config from config.json
       leaves the section unreconciled, so a previously enabled SCIM would stay enabled.
       bifrost.scim has no default, so charts that never declare it emit nothing and leave
       dashboard-configured SCIM alone. Gate on key presence, not truthiness: an empty or nil
       map is falsy in Go templates, so `if .Values.bifrost.scim` would treat `scim: {}` as
       undeclared and skip the section. */ -}}
{{- if hasKey .Values.bifrost "scim" }}
{{- $scimValues := default dict .Values.bifrost.scim }}
{{- $scim := dict "enabled" (default false $scimValues.enabled) }}
{{- if $scimValues.provider }}
{{- $_ := set $scim "provider" $scimValues.provider }}
{{- end }}
{{- if $scimValues.config }}
{{- $_ := set $scim "config" $scimValues.config }}
{{- end }}
{{- /* Gate on key presence, not truthiness: an explicit empty list means "clear the stored
       allowlist" and must still render, while an undeclared key leaves it untouched. */ -}}
{{- if hasKey $scimValues "trustedNetworks" }}
{{- $_ := set $scim "trusted_networks" (default (list) $scimValues.trustedNetworks) }}
{{- end }}
{{- $_ := set $config "scim_config" $scim }}
{{- end }}
{{- /* Load Balancer Config */ -}}
{{- if and .Values.bifrost.loadBalancer .Values.bifrost.loadBalancer.enabled }}
{{- $lb := dict }}
{{- if hasKey .Values.bifrost.loadBalancer "directionSelectionEnabled" }}
{{- $_ := set $lb "direction_selection_enabled" .Values.bifrost.loadBalancer.directionSelectionEnabled }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "routeSelectionEnabled" }}
{{- $_ := set $lb "route_selection_enabled" .Values.bifrost.loadBalancer.routeSelectionEnabled }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "appendFallbacksToPinned" }}
{{- $_ := set $lb "append_fallbacks_to_pinned" .Values.bifrost.loadBalancer.appendFallbacksToPinned }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "rerouteFailedDirections" }}
{{- $_ := set $lb "reroute_failed_directions" .Values.bifrost.loadBalancer.rerouteFailedDirections }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "pruneFailedFallbacks" }}
{{- $_ := set $lb "prune_failed_fallbacks" .Values.bifrost.loadBalancer.pruneFailedFallbacks }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "rerouteTarget" }}
{{- $_ := set $lb "reroute_target" .Values.bifrost.loadBalancer.rerouteTarget }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "historyEnabled" }}
{{- $_ := set $lb "history_enabled" .Values.bifrost.loadBalancer.historyEnabled }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "historyRetentionDays" }}
{{- $_ := set $lb "history_retention_days" .Values.bifrost.loadBalancer.historyRetentionDays }}
{{- end }}
{{- if hasKey .Values.bifrost.loadBalancer "snapshotPersistIntervalSeconds" }}
{{- $_ := set $lb "snapshot_persist_interval_seconds" .Values.bifrost.loadBalancer.snapshotPersistIntervalSeconds }}
{{- end }}
{{- $_ := set $config "load_balancer_config" $lb }}
{{- end }}
{{- /* Guardrails Config */ -}}
{{- if .Values.bifrost.guardrails }}
{{- $guardrails := dict }}
{{- if .Values.bifrost.guardrails.rules }}
{{- $rules := list }}
{{- range .Values.bifrost.guardrails.rules }}
{{- $rule := dict "id" .id "name" .name "enabled" .enabled "cel_expression" .cel_expression "apply_to" .apply_to }}
{{- if .description }}{{- $_ := set $rule "description" .description }}{{- end }}
{{- if hasKey . "target" }}{{- $_ := set $rule "target" .target }}{{- end }}
{{- if hasKey . "query" }}{{- $_ := set $rule "query" .query }}{{- end }}
{{- if .sampling_rate }}{{- $_ := set $rule "sampling_rate" .sampling_rate }}{{- end }}
{{- if .timeout }}{{- $_ := set $rule "timeout" .timeout }}{{- end }}
{{- if hasKey . "send_all_conversation_turns" }}{{- $_ := set $rule "send_all_conversation_turns" .send_all_conversation_turns }}{{- end }}
{{- if hasKey . "max_turns_to_send" }}{{- $_ := set $rule "max_turns_to_send" .max_turns_to_send }}{{- end }}
{{- if .evaluation_mode }}{{- $_ := set $rule "evaluation_mode" .evaluation_mode }}{{- end }}
{{- if hasKey . "stream_replay_event_interval_ms" }}{{- $_ := set $rule "stream_replay_event_interval_ms" .stream_replay_event_interval_ms }}{{- end }}
{{- if .output_mode }}{{- $_ := set $rule "output_mode" .output_mode }}{{- end }}
{{- if .provider_config_ids }}{{- $_ := set $rule "provider_config_ids" .provider_config_ids }}{{- end }}
{{- $rules = append $rules $rule }}
{{- end }}
{{- $_ := set $guardrails "guardrail_rules" $rules }}
{{- end }}
{{- if .Values.bifrost.guardrails.providers }}
{{- $providers := list }}
{{- range .Values.bifrost.guardrails.providers }}
{{- $provider := dict "id" .id "provider_name" .provider_name "policy_name" .policy_name "enabled" .enabled }}
{{- if .timeout }}{{- $_ := set $provider "timeout" .timeout }}{{- end }}
{{- if .config }}{{- $_ := set $provider "config" .config }}{{- end }}
{{- $providers = append $providers $provider }}
{{- end }}
{{- $_ := set $guardrails "guardrail_providers" $providers }}
{{- end }}
{{- if or $guardrails.guardrail_rules $guardrails.guardrail_providers }}
{{- $_ := set $config "guardrails_config" $guardrails }}
{{- end }}
{{- end }}
{{- /* Skills Registry */ -}}
{{- if .Values.bifrost.skillsRegistry }}
{{- $_ := set $config "skills_registry" .Values.bifrost.skillsRegistry }}
{{- end }}
{{- /* Access Profiles (Enterprise) */ -}}
{{- if .Values.bifrost.accessProfiles }}
{{- $_ := set $config "access_profiles" .Values.bifrost.accessProfiles }}
{{- end }}
{{- /* Alerting */ -}}
{{- if .Values.bifrost.alerting }}
{{- if .Values.bifrost.alerting.rules }}
{{- range .Values.bifrost.alerting.rules }}
{{- if and (hasKey . "target_type") (not (hasKey . "target_id")) }}
{{- fail (printf "alerting rule '%s': target_type is set but target_id is missing" .id) }}
{{- end }}
{{- if and (hasKey . "target_id") (not (hasKey . "target_type")) }}
{{- fail (printf "alerting rule '%s': target_id is set but target_type is missing" .id) }}
{{- end }}
{{- end }}
{{- end }}
{{- $_ := set $config "alerting" .Values.bifrost.alerting }}
{{- end }}
{{- /* Webhooks */ -}}
{{- if .Values.bifrost.webhooks }}
{{- $seenWebhookNames := list }}
{{- range .Values.bifrost.webhooks }}
{{- if not .name }}
{{- fail "ERROR: bifrost.webhooks[].name is required for every webhook endpoint." }}
{{- end }}
{{- if has .name $seenWebhookNames }}
{{- fail (printf "ERROR: bifrost.webhooks[].name '%s' is used by more than one endpoint. Names must be unique; startup reconciliation identifies endpoints by name." .name) }}
{{- end }}
{{- $seenWebhookNames = append $seenWebhookNames .name }}
{{- if not .url }}
{{- fail (printf "ERROR: bifrost.webhooks[].url is required for webhook endpoint '%s'." .name) }}
{{- end }}
{{- if not .events }}
{{- fail (printf "ERROR: bifrost.webhooks[].events is required for webhook endpoint '%s'." .name) }}
{{- end }}
{{- if ne (len .events) (len (uniq .events)) }}
{{- fail (printf "ERROR: bifrost.webhooks[].events for endpoint '%s' contains duplicate entries. Each event may be listed at most once." .name) }}
{{- end }}
{{- end }}
{{- $_ := set $config "webhooks" .Values.bifrost.webhooks }}
{{- end }}
{{- /* Agents (A2A agent registrations) */ -}}
{{- if hasKey .Values.bifrost "agents" }}
{{- $seenAgentNames := list }}
{{- range .Values.bifrost.agents }}
{{- if not .name }}
{{- fail "ERROR: bifrost.agents[].name is required for every agent registration." }}
{{- end }}
{{- if has .name $seenAgentNames }}
{{- fail (printf "ERROR: bifrost.agents[].name '%s' is used by more than one agent. Names must be unique; startup reconciliation identifies agents by name." .name) }}
{{- end }}
{{- $seenAgentNames = append $seenAgentNames .name }}
{{- if not .agent_card_url }}
{{- fail (printf "ERROR: bifrost.agents[].agent_card_url is required for agent '%s'." .name) }}
{{- end }}
{{- end }}
{{- $_ := set $config "agents" .Values.bifrost.agents }}
{{- end }}
{{- /* Config Store */ -}}
{{- if .Values.storage.configStore.enabled }}
{{- $configStoreType := .Values.storage.configStore.type | default .Values.storage.mode }}
{{- if eq $configStoreType "postgres" }}
{{- $pgConfig := dict "host" (include "bifrost.postgresql.host" .) "port" (include "bifrost.postgresql.port" .) "db_name" (include "bifrost.postgresql.database" .) "user" (include "bifrost.postgresql.username" .) "password" (include "bifrost.postgresql.password" .) "ssl_mode" (include "bifrost.postgresql.sslMode" .) }}
{{- if and .Values.postgresql.external.enabled .Values.postgresql.external.passwordCommand }}
{{- $_ := set $pgConfig "password_command" .Values.postgresql.external.passwordCommand }}
{{- $_ := unset $pgConfig "password" }}
{{- end }}
{{- if and .Values.postgresql.external.enabled .Values.postgresql.external.connMaxLifetime }}
{{- $_ := set $pgConfig "conn_max_lifetime" .Values.postgresql.external.connMaxLifetime }}
{{- end }}
{{- if .Values.storage.configStore.maxIdleConns }}
{{- $_ := set $pgConfig "max_idle_conns" (.Values.storage.configStore.maxIdleConns | int) }}
{{- end }}
{{- if .Values.storage.configStore.maxOpenConns }}
{{- $_ := set $pgConfig "max_open_conns" (.Values.storage.configStore.maxOpenConns | int) }}
{{- end }}
{{- if .Values.storage.configStore.connMaxIdleTime }}
{{- $_ := set $pgConfig "conn_max_idle_time" .Values.storage.configStore.connMaxIdleTime }}
{{- end }}
{{- with .Values.storage.configStore.statementTimeout }}{{- $_ := set $pgConfig "statement_timeout" (toString .) }}{{- end }}
{{- with .Values.storage.configStore.idleInTransactionSessionTimeout }}{{- $_ := set $pgConfig "idle_in_transaction_session_timeout" (toString .) }}{{- end }}
{{- with .Values.storage.configStore.migrationLockRetryBudget }}{{- $_ := set $pgConfig "migration_lock_retry_budget" (toString .) }}{{- end }}
{{- $configStore := dict "enabled" true "type" "postgres" "config" $pgConfig }}
{{- $_ := set $config "config_store" $configStore }}
{{- else }}
{{- $sqliteConfigStore := dict "enabled" true "type" "sqlite" "config" (dict "path" (printf "%s/config.db" .Values.bifrost.appDir)) }}
{{- $_ := set $config "config_store" $sqliteConfigStore }}
{{- end }}
{{- /* Vault Store (enterprise secret management) */ -}}
{{- if and .Values.storage.configStore.vaultStore .Values.storage.configStore.vaultStore.enabled }}
{{- $vs := .Values.storage.configStore.vaultStore }}
{{- $vaultStore := dict "enabled" true "type" $vs.type }}
{{- if $vs.prefix }}
{{- $_ := set $vaultStore "prefix" $vs.prefix }}
{{- end }}
{{- if $vs.accessMode }}
{{- $_ := set $vaultStore "access_mode" $vs.accessMode }}
{{- end }}
{{- if $vs.aws }}
{{- $aws := dict }}
{{- if $vs.aws.region }}{{- $_ := set $aws "region" $vs.aws.region }}{{- end }}
{{- if $vs.aws.accessKeyId }}{{- $_ := set $aws "access_key_id" $vs.aws.accessKeyId }}{{- end }}
{{- if $vs.aws.secretAccessKey }}{{- $_ := set $aws "secret_access_key" $vs.aws.secretAccessKey }}{{- end }}
{{- if $vs.aws.sessionToken }}{{- $_ := set $aws "session_token" $vs.aws.sessionToken }}{{- end }}
{{- if $vs.aws.roleArn }}{{- $_ := set $aws "role_arn" $vs.aws.roleArn }}{{- end }}
{{- if $vs.aws.kmsKeyId }}{{- $_ := set $aws "kms_key_id" $vs.aws.kmsKeyId }}{{- end }}
{{- $_ := set $vaultStore "aws" $aws }}
{{- end }}
{{- if $vs.gcp }}
{{- $gcp := dict }}
{{- if $vs.gcp.projectId }}{{- $_ := set $gcp "project_id" $vs.gcp.projectId }}{{- end }}
{{- if $vs.gcp.credentialsJson }}{{- $_ := set $gcp "credentials_json" $vs.gcp.credentialsJson }}{{- end }}
{{- $_ := set $vaultStore "gcp" $gcp }}
{{- end }}
{{- if $vs.hashicorp }}
{{- $hashicorp := dict }}
{{- if $vs.hashicorp.address }}{{- $_ := set $hashicorp "address" $vs.hashicorp.address }}{{- end }}
{{- if $vs.hashicorp.token }}{{- $_ := set $hashicorp "token" $vs.hashicorp.token }}{{- end }}
{{- if $vs.hashicorp.namespace }}{{- $_ := set $hashicorp "namespace" $vs.hashicorp.namespace }}{{- end }}
{{- if $vs.hashicorp.mountPath }}{{- $_ := set $hashicorp "mount_path" $vs.hashicorp.mountPath }}{{- end }}
{{- if $vs.hashicorp.roleId }}{{- $_ := set $hashicorp "role_id" $vs.hashicorp.roleId }}{{- end }}
{{- if $vs.hashicorp.secretId }}{{- $_ := set $hashicorp "secret_id" $vs.hashicorp.secretId }}{{- end }}
{{- if $vs.hashicorp.kubernetesRole }}{{- $_ := set $hashicorp "kubernetes_role" $vs.hashicorp.kubernetesRole }}{{- end }}
{{- if $vs.hashicorp.kubernetesMountPath }}{{- $_ := set $hashicorp "kubernetes_mount_path" $vs.hashicorp.kubernetesMountPath }}{{- end }}
{{- if $vs.hashicorp.kubernetesTokenPath }}{{- $_ := set $hashicorp "kubernetes_token_path" $vs.hashicorp.kubernetesTokenPath }}{{- end }}
{{- $_ := set $vaultStore "hashicorp" $hashicorp }}
{{- end }}
{{- if $vs.azure }}
{{- $azure := dict }}
{{- if $vs.azure.vaultUrl }}{{- $_ := set $azure "vault_url" $vs.azure.vaultUrl }}{{- end }}
{{- if $vs.azure.tenantId }}{{- $_ := set $azure "tenant_id" $vs.azure.tenantId }}{{- end }}
{{- if $vs.azure.clientId }}{{- $_ := set $azure "client_id" $vs.azure.clientId }}{{- end }}
{{- if $vs.azure.clientSecret }}{{- $_ := set $azure "client_secret" $vs.azure.clientSecret }}{{- end }}
{{- $_ := set $vaultStore "azure" $azure }}
{{- end }}
{{- $cs := index $config "config_store" }}
{{- $_ := set $cs "vault_store" $vaultStore }}
{{- end }}
{{- end }}
{{- /* Logs Store */ -}}
{{- if .Values.storage.logsStore.enabled }}
{{- $logsStoreType := .Values.storage.logsStore.type | default .Values.storage.mode }}
{{- if eq $logsStoreType "postgres" }}
{{- $pgConfig := dict "host" (include "bifrost.logsPostgresql.host" .) "port" (include "bifrost.logsPostgresql.port" .) "db_name" (include "bifrost.logsPostgresql.database" .) "user" (include "bifrost.logsPostgresql.username" .) "password" (include "bifrost.logsPostgresql.password" .) "ssl_mode" (include "bifrost.logsPostgresql.sslMode" .) }}
{{- if dig "postgres" "enabled" false .Values.storage.logsStore }}
{{- if .Values.storage.logsStore.postgres.passwordCommand }}
{{- $_ := set $pgConfig "password_command" .Values.storage.logsStore.postgres.passwordCommand }}
{{- $_ := unset $pgConfig "password" }}
{{- end }}
{{- if .Values.storage.logsStore.postgres.connMaxLifetime }}
{{- $_ := set $pgConfig "conn_max_lifetime" .Values.storage.logsStore.postgres.connMaxLifetime }}
{{- end }}
{{- else }}
{{- if and .Values.postgresql.external.enabled .Values.postgresql.external.passwordCommand }}
{{- $_ := set $pgConfig "password_command" .Values.postgresql.external.passwordCommand }}
{{- $_ := unset $pgConfig "password" }}
{{- end }}
{{- if and .Values.postgresql.external.enabled .Values.postgresql.external.connMaxLifetime }}
{{- $_ := set $pgConfig "conn_max_lifetime" .Values.postgresql.external.connMaxLifetime }}
{{- end }}
{{- end }}
{{- if .Values.storage.logsStore.maxIdleConns }}
{{- $_ := set $pgConfig "max_idle_conns" (.Values.storage.logsStore.maxIdleConns | int) }}
{{- end }}
{{- if .Values.storage.logsStore.maxOpenConns }}
{{- $_ := set $pgConfig "max_open_conns" (.Values.storage.logsStore.maxOpenConns | int) }}
{{- end }}
{{- if .Values.storage.logsStore.matviewRefreshInterval }}
{{- $_ := set $pgConfig "matview_refresh_interval" .Values.storage.logsStore.matviewRefreshInterval }}
{{- end }}
{{- if .Values.storage.logsStore.matviewRefreshTimeout }}
{{- $_ := set $pgConfig "matview_refresh_timeout" .Values.storage.logsStore.matviewRefreshTimeout }}
{{- end }}
{{- if .Values.storage.logsStore.migrationMatviewCancelAfter }}
{{- $_ := set $pgConfig "migration_matview_cancel_after" .Values.storage.logsStore.migrationMatviewCancelAfter }}
{{- end }}
{{- if .Values.storage.logsStore.connMaxIdleTime }}
{{- $_ := set $pgConfig "conn_max_idle_time" .Values.storage.logsStore.connMaxIdleTime }}
{{- end }}
{{- with .Values.storage.logsStore.statementTimeout }}{{- $_ := set $pgConfig "statement_timeout" (toString .) }}{{- end }}
{{- with .Values.storage.logsStore.idleInTransactionSessionTimeout }}{{- $_ := set $pgConfig "idle_in_transaction_session_timeout" (toString .) }}{{- end }}
{{- with .Values.storage.logsStore.migrationLockRetryBudget }}{{- $_ := set $pgConfig "migration_lock_retry_budget" (toString .) }}{{- end }}
{{- $logsStore := dict "enabled" true "type" "postgres" "config" $pgConfig }}
{{- if .Values.storage.logsStore.writer }}
{{- $writer := dict }}
{{- with .Values.storage.logsStore.writer.maxBatchSize }}{{- $_ := set $writer "max_batch_size" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.batchInterval }}{{- $_ := set $writer "batch_interval" . }}{{- end }}
{{- with .Values.storage.logsStore.writer.maxBatchBytes }}{{- $_ := set $writer "max_batch_bytes" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.writeQueueCapacity }}{{- $_ := set $writer "write_queue_capacity" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.deferredUsageConcurrency }}{{- $_ := set $writer "deferred_usage_concurrency" (. | int) }}{{- end }}
{{- if $writer }}{{- $_ := set $logsStore "writer" $writer }}{{- end }}
{{- end }}
{{- $_ := set $config "logs_store" $logsStore }}
{{- else if eq $logsStoreType "clickhouse" }}
{{- if not .Values.storage.logsStore.clickhouse }}{{- fail "ERROR: storage.logsStore.clickhouse is required when storage.logsStore.type is 'clickhouse'." }}{{- end }}
{{- if not .Values.storage.logsStore.clickhouse.host }}{{- fail "ERROR: storage.logsStore.clickhouse.host is required when storage.logsStore.type is 'clickhouse'." }}{{- end }}
{{- $ch := .Values.storage.logsStore.clickhouse }}
{{- $chConfig := dict "host" $ch.host }}
{{- with $ch.port }}{{- $_ := set $chConfig "port" (. | toString) }}{{- end }}
{{- with $ch.database }}{{- $_ := set $chConfig "database" . }}{{- end }}
{{- with $ch.username }}{{- $_ := set $chConfig "username" . }}{{- end }}
{{- with $ch.password }}{{- $_ := set $chConfig "password" . }}{{- end }}
{{- with $ch.protocol }}{{- $_ := set $chConfig "protocol" . }}{{- end }}
{{- if hasKey $ch "secure" }}{{- $_ := set $chConfig "secure" $ch.secure }}{{- end }}
{{- with $ch.dialTimeout }}{{- $_ := set $chConfig "dial_timeout" (. | int) }}{{- end }}
{{- with $ch.maxQuerySize }}{{- $_ := set $chConfig "max_query_size" (. | int) }}{{- end }}
{{- with $ch.cluster }}{{- $_ := set $chConfig "cluster" . }}{{- end }}
{{- $clickhouseLogsStore := dict "enabled" true "type" "clickhouse" "config" $chConfig }}
{{- if .Values.storage.logsStore.writer }}
{{- $writer := dict }}
{{- with .Values.storage.logsStore.writer.maxBatchSize }}{{- $_ := set $writer "max_batch_size" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.batchInterval }}{{- $_ := set $writer "batch_interval" . }}{{- end }}
{{- with .Values.storage.logsStore.writer.maxBatchBytes }}{{- $_ := set $writer "max_batch_bytes" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.writeQueueCapacity }}{{- $_ := set $writer "write_queue_capacity" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.deferredUsageConcurrency }}{{- $_ := set $writer "deferred_usage_concurrency" (. | int) }}{{- end }}
{{- if $writer }}{{- $_ := set $clickhouseLogsStore "writer" $writer }}{{- end }}
{{- end }}
{{- $_ := set $config "logs_store" $clickhouseLogsStore }}
{{- else }}
{{- $sqliteLogsStore := dict "enabled" true "type" "sqlite" "config" (dict "path" (printf "%s/logs.db" .Values.bifrost.appDir)) }}
{{- if .Values.storage.logsStore.writer }}
{{- $writer := dict }}
{{- with .Values.storage.logsStore.writer.maxBatchSize }}{{- $_ := set $writer "max_batch_size" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.batchInterval }}{{- $_ := set $writer "batch_interval" . }}{{- end }}
{{- with .Values.storage.logsStore.writer.maxBatchBytes }}{{- $_ := set $writer "max_batch_bytes" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.writeQueueCapacity }}{{- $_ := set $writer "write_queue_capacity" (. | int) }}{{- end }}
{{- with .Values.storage.logsStore.writer.deferredUsageConcurrency }}{{- $_ := set $writer "deferred_usage_concurrency" (. | int) }}{{- end }}
{{- if $writer }}{{- $_ := set $sqliteLogsStore "writer" $writer }}{{- end }}
{{- end }}
{{- $_ := set $config "logs_store" $sqliteLogsStore }}
{{- end }}
{{- /* Object Storage for log payloads */ -}}
{{- if and .Values.storage.logsStore.objectStorage .Values.storage.logsStore.objectStorage.enabled }}
{{- $os := .Values.storage.logsStore.objectStorage }}
{{- $osConfig := dict "type" $os.type "bucket" $os.bucket }}
{{- if $os.prefix }}
{{- $_ := set $osConfig "prefix" $os.prefix }}
{{- end }}
{{- if $os.compress }}
{{- $_ := set $osConfig "compress" true }}
{{- end }}
{{- if eq $os.type "s3" }}
{{- if $os.region }}
{{- $_ := set $osConfig "region" $os.region }}
{{- end }}
{{- if $os.endpoint }}
{{- $_ := set $osConfig "endpoint" $os.endpoint }}
{{- end }}
{{- if $os.existingSecret }}
{{- if $os.accessKeyIdKey }}
{{- $_ := set $osConfig "access_key_id" "env.BIFROST_OBJECT_STORAGE_ACCESS_KEY_ID" }}
{{- end }}
{{- if $os.secretAccessKeyKey }}
{{- $_ := set $osConfig "secret_access_key" "env.BIFROST_OBJECT_STORAGE_SECRET_ACCESS_KEY" }}
{{- end }}
{{- if $os.sessionTokenKey }}
{{- $_ := set $osConfig "session_token" "env.BIFROST_OBJECT_STORAGE_SESSION_TOKEN" }}
{{- end }}
{{- $_ := set $osConfig "role_arn" "env.BIFROST_OBJECT_STORAGE_ROLE_ARN" }}
{{- else }}
{{- if $os.accessKeyId }}
{{- $_ := set $osConfig "access_key_id" $os.accessKeyId }}
{{- end }}
{{- if $os.secretAccessKey }}
{{- $_ := set $osConfig "secret_access_key" $os.secretAccessKey }}
{{- end }}
{{- if $os.sessionToken }}
{{- $_ := set $osConfig "session_token" $os.sessionToken }}
{{- end }}
{{- if $os.roleArn }}
{{- $_ := set $osConfig "role_arn" $os.roleArn }}
{{- end }}
{{- end }}
{{- if $os.forcePathStyle }}
{{- $_ := set $osConfig "force_path_style" true }}
{{- end }}
{{- end }}
{{- if eq $os.type "gcs" }}
{{- if $os.projectId }}
{{- $_ := set $osConfig "project_id" $os.projectId }}
{{- end }}
{{- if $os.existingSecret }}
{{- $_ := set $osConfig "credentials_json" "env.BIFROST_OBJECT_STORAGE_CREDENTIALS_JSON" }}
{{- else if $os.credentialsJson }}
{{- $_ := set $osConfig "credentials_json" $os.credentialsJson }}
{{- end }}
{{- end }}
{{- $_ := set (index $config "logs_store") "object_storage" $osConfig }}
{{- end }}
{{- if .Values.storage.logsStore.objectStorageExcludeFields }}
{{- $_ := set (index $config "logs_store") "object_storage_exclude_fields" .Values.storage.logsStore.objectStorageExcludeFields }}
{{- end }}
{{- if .Values.storage.logsStore.objectStorageExcludeRequestTypes }}
{{- $_ := set (index $config "logs_store") "object_storage_exclude_request_types" .Values.storage.logsStore.objectStorageExcludeRequestTypes }}
{{- end }}
{{- end }}
{{- /* Vector Store */ -}}
{{- if and .Values.vectorStore.enabled (ne .Values.vectorStore.type "none") }}
{{- $vectorStore := dict "enabled" true "type" .Values.vectorStore.type }}
{{- if eq .Values.vectorStore.type "weaviate" }}
{{- $weaviateConfig := dict "scheme" (include "bifrost.weaviate.scheme" .) "host" (include "bifrost.weaviate.host" .) }}
{{- if .Values.vectorStore.weaviate.external.enabled }}
{{- $weaviateApiKey := include "bifrost.weaviate.apiKey" . }}
{{- if $weaviateApiKey }}
{{- $_ := set $weaviateConfig "api_key" $weaviateApiKey }}
{{- end }}
{{- if or .Values.vectorStore.weaviate.external.grpcHost (hasKey .Values.vectorStore.weaviate.external "grpcSecured") }}
{{- $grpcConfig := dict }}
{{- if .Values.vectorStore.weaviate.external.grpcHost }}
{{- $_ := set $grpcConfig "host" .Values.vectorStore.weaviate.external.grpcHost }}
{{- end }}
{{- if hasKey .Values.vectorStore.weaviate.external "grpcSecured" }}
{{- $_ := set $grpcConfig "secured" .Values.vectorStore.weaviate.external.grpcSecured }}
{{- end }}
{{- $_ := set $weaviateConfig "grpc_config" $grpcConfig }}
{{- end }}
{{- if .Values.vectorStore.weaviate.external.timeout }}
{{- $_ := set $weaviateConfig "timeout" .Values.vectorStore.weaviate.external.timeout }}
{{- end }}
{{- if .Values.vectorStore.weaviate.external.className }}
{{- $_ := set $weaviateConfig "class_name" .Values.vectorStore.weaviate.external.className }}
{{- end }}
{{- end }}
{{- $_ := set $vectorStore "config" $weaviateConfig }}
{{- else if eq .Values.vectorStore.type "redis" }}
{{- $redisConfig := dict "addr" (printf "%s:%s" (include "bifrost.redis.host" .) (include "bifrost.redis.port" .)) }}
{{- $password := include "bifrost.redis.password" . }}
{{- if $password }}
{{- $_ := set $redisConfig "password" $password }}
{{- end }}
{{- if .Values.vectorStore.redis.external.enabled }}
{{- if .Values.vectorStore.redis.external.username }}
{{- $_ := set $redisConfig "username" .Values.vectorStore.redis.external.username }}
{{- end }}
{{- if .Values.vectorStore.redis.external.database }}
{{- $_ := set $redisConfig "db" .Values.vectorStore.redis.external.database }}
{{- end }}
{{- if .Values.vectorStore.redis.external.poolSize }}
{{- $_ := set $redisConfig "pool_size" .Values.vectorStore.redis.external.poolSize }}
{{- end }}
{{- if .Values.vectorStore.redis.external.maxActiveConns }}
{{- $_ := set $redisConfig "max_active_conns" .Values.vectorStore.redis.external.maxActiveConns }}
{{- end }}
{{- if .Values.vectorStore.redis.external.minIdleConns }}
{{- $_ := set $redisConfig "min_idle_conns" .Values.vectorStore.redis.external.minIdleConns }}
{{- end }}
{{- if .Values.vectorStore.redis.external.maxIdleConns }}
{{- $_ := set $redisConfig "max_idle_conns" .Values.vectorStore.redis.external.maxIdleConns }}
{{- end }}
{{- if .Values.vectorStore.redis.external.connMaxLifetime }}
{{- $_ := set $redisConfig "conn_max_lifetime" .Values.vectorStore.redis.external.connMaxLifetime }}
{{- end }}
{{- if .Values.vectorStore.redis.external.connMaxIdleTime }}
{{- $_ := set $redisConfig "conn_max_idle_time" .Values.vectorStore.redis.external.connMaxIdleTime }}
{{- end }}
{{- if .Values.vectorStore.redis.external.dialTimeout }}
{{- $_ := set $redisConfig "dial_timeout" .Values.vectorStore.redis.external.dialTimeout }}
{{- end }}
{{- if .Values.vectorStore.redis.external.readTimeout }}
{{- $_ := set $redisConfig "read_timeout" .Values.vectorStore.redis.external.readTimeout }}
{{- end }}
{{- if .Values.vectorStore.redis.external.writeTimeout }}
{{- $_ := set $redisConfig "write_timeout" .Values.vectorStore.redis.external.writeTimeout }}
{{- end }}
{{- if .Values.vectorStore.redis.external.contextTimeout }}
{{- $_ := set $redisConfig "context_timeout" .Values.vectorStore.redis.external.contextTimeout }}
{{- end }}
{{- if .Values.vectorStore.redis.external.useTls }}
{{- $_ := set $redisConfig "use_tls" true }}
{{- end }}
{{- if .Values.vectorStore.redis.external.insecureSkipVerify }}
{{- $_ := set $redisConfig "insecure_skip_verify" true }}
{{- end }}
{{- if .Values.vectorStore.redis.external.caCertPem }}
{{- $_ := set $redisConfig "ca_cert_pem" .Values.vectorStore.redis.external.caCertPem }}
{{- end }}
{{- if .Values.vectorStore.redis.external.clusterMode }}
{{- $_ := set $redisConfig "cluster_mode" true }}
{{- end }}
{{- end }}
{{- $_ := set $vectorStore "config" $redisConfig }}
{{- else if eq .Values.vectorStore.type "qdrant" }}
{{- $qdrantConfig := dict "host" (include "bifrost.qdrant.host" .) "port" (include "bifrost.qdrant.port" . | int) }}
{{- $apiKey := include "bifrost.qdrant.apiKey" . }}
{{- if $apiKey }}
{{- $_ := set $qdrantConfig "api_key" $apiKey }}
{{- end }}
{{- $useTls := include "bifrost.qdrant.useTls" . }}
{{- if eq $useTls "true" }}
{{- $_ := set $qdrantConfig "use_tls" true }}
{{- else }}
{{- $_ := set $qdrantConfig "use_tls" false }}
{{- end }}
{{- $_ := set $vectorStore "config" $qdrantConfig }}
{{- else if eq .Values.vectorStore.type "pinecone" }}
{{- $pineconeConfig := dict }}
{{- $apiKey := include "bifrost.pinecone.apiKey" . }}
{{- if $apiKey }}
{{- $_ := set $pineconeConfig "api_key" $apiKey }}
{{- end }}
{{- if .Values.vectorStore.pinecone.external.indexHost }}
{{- $_ := set $pineconeConfig "index_host" .Values.vectorStore.pinecone.external.indexHost }}
{{- end }}
{{- $_ := set $vectorStore "config" $pineconeConfig }}
{{- else if eq .Values.vectorStore.type "chromem" }}
{{- $chromemConfig := dict }}
{{- with .Values.vectorStore.chromem }}
{{- if .path }}
{{- $_ := set $chromemConfig "path" .path }}
{{- end }}
{{- if hasKey . "compress" }}
{{- $_ := set $chromemConfig "compress" .compress }}
{{- end }}
{{- end }}
{{- $_ := set $vectorStore "config" $chromemConfig }}
{{- end }}
{{- $_ := set $config "vector_store" $vectorStore }}
{{- end }}
{{- /* MCP */ -}}
{{- if .Values.bifrost.mcp.enabled }}
{{- $clientConfigs := list }}
{{- range $idx, $client := .Values.bifrost.mcp.clientConfigs }}
{{- $cc := dict "name" $client.name }}
{{- /* Map connectionType: websocket -> sse, others pass through */ -}}
{{- if eq $client.connectionType "websocket" }}
{{- $_ := set $cc "connection_type" "sse" }}
{{- else }}
{{- $_ := set $cc "connection_type" $client.connectionType }}
{{- end }}
{{- /* Map httpConfig.url / websocketConfig.url -> connection_string */ -}}
{{- if and (eq $client.connectionType "http") $client.httpConfig }}
{{- $_ := set $cc "connection_string" $client.httpConfig.url }}
{{- end }}
{{- if and (eq $client.connectionType "websocket") $client.websocketConfig }}
{{- $_ := set $cc "connection_string" $client.websocketConfig.url }}
{{- end }}
{{- /* Map connectionString for SSE connections */ -}}
{{- if and (eq $client.connectionType "sse") $client.connectionString }}
{{- $_ := set $cc "connection_string" $client.connectionString }}
{{- end }}
{{- /* Map stdioConfig -> stdio_config */ -}}
{{- if $client.stdioConfig }}
{{- $stdio := dict "command" $client.stdioConfig.command }}
{{- if $client.stdioConfig.args }}
{{- $_ := set $stdio "args" $client.stdioConfig.args }}
{{- end }}
{{- if $client.stdioConfig.envs }}
{{- $_ := set $stdio "envs" $client.stdioConfig.envs }}
{{- end }}
{{- $_ := set $cc "stdio_config" $stdio }}
{{- end }}
{{- /* Pass through fields that are already snake_case or flat */ -}}
{{- if $client.headers }}
{{- $_ := set $cc "headers" $client.headers }}
{{- end }}
{{- if hasKey $client "tools_to_execute" }}
{{- $_ := set $cc "tools_to_execute" $client.tools_to_execute }}
{{- else if hasKey $client "toolsToExecute" }}
{{- $_ := set $cc "tools_to_execute" $client.toolsToExecute }}
{{- end }}
{{- if hasKey $client "tools_to_auto_execute" }}
{{- $_ := set $cc "tools_to_auto_execute" $client.tools_to_auto_execute }}
{{- else if hasKey $client "toolsToAutoExecute" }}
{{- $_ := set $cc "tools_to_auto_execute" $client.toolsToAutoExecute }}
{{- end }}
{{- if hasKey $client "auth_type" }}
{{- $_ := set $cc "auth_type" $client.auth_type }}
{{- else if hasKey $client "authType" }}
{{- $_ := set $cc "auth_type" $client.authType }}
{{- end }}
{{- /* Inline OAuth provider config for auth_type "oauth"/"per_user_oauth". oauth_config_id is Bifrost-managed (minted by the admin verification flow) and is ignored when supplied via config.json, so it is not rendered here. */ -}}
{{- if $client.oauthConfig }}
{{- $oauthCfg := dict }}
{{- with $client.oauthConfig.clientId }}{{- $_ := set $oauthCfg "client_id" . }}{{- end }}
{{- with $client.oauthConfig.clientSecret }}{{- $_ := set $oauthCfg "client_secret" . }}{{- end }}
{{- with $client.oauthConfig.authorizeUrl }}{{- $_ := set $oauthCfg "authorize_url" . }}{{- end }}
{{- with $client.oauthConfig.tokenUrl }}{{- $_ := set $oauthCfg "token_url" . }}{{- end }}
{{- with $client.oauthConfig.registrationUrl }}{{- $_ := set $oauthCfg "registration_url" . }}{{- end }}
{{- with $client.oauthConfig.scopes }}{{- $_ := set $oauthCfg "scopes" . }}{{- end }}
{{- /* Only emit oauth_config when at least one field resolved; an all-empty block would render "oauth_config": {} instead of relying on discovery. */ -}}
{{- if $oauthCfg }}
{{- $_ := set $cc "oauth_config" $oauthCfg }}
{{- end }}
{{- end }}
{{- /* Delegated token-exchange config for auth_type "token_exchange" (Enterprise builds only). */ -}}
{{- if $client.tokenExchange }}
{{- $te := dict }}
{{- with $client.tokenExchange.audience }}{{- $_ := set $te "audience" . }}{{- end }}
{{- if hasKey $client.tokenExchange "useIdpCredentials" }}{{- $_ := set $te "use_idp_credentials" $client.tokenExchange.useIdpCredentials }}{{- end }}
{{- with $client.tokenExchange.clientId }}{{- $_ := set $te "client_id" . }}{{- end }}
{{- with $client.tokenExchange.clientSecret }}{{- $_ := set $te "client_secret" . }}{{- end }}
{{- with $client.tokenExchange.authorizationServerUrl }}{{- $_ := set $te "authorization_server_url" . }}{{- end }}
{{- with $client.tokenExchange.scopes }}{{- $_ := set $te "scopes" . }}{{- end }}
{{- $_ := set $cc "token_exchange" $te }}
{{- end }}
{{- if hasKey $client "isPingAvailable" }}
{{- $_ := set $cc "is_ping_available" $client.isPingAvailable }}
{{- end }}
{{- if hasKey $client "needsSessionStickiness" }}
{{- $_ := set $cc "needs_session_stickiness" $client.needsSessionStickiness }}
{{- end }}
{{- if $client.clientId }}
{{- $_ := set $cc "client_id" $client.clientId }}
{{- end }}
{{- if hasKey $client "isCodeModeClient" }}
{{- $_ := set $cc "is_code_mode_client" $client.isCodeModeClient }}
{{- end }}
{{- if $client.toolSyncInterval }}
{{- $_ := set $cc "tool_sync_interval" $client.toolSyncInterval }}
{{- end }}
{{- if hasKey $client "toolExecutionTimeout" }}
{{- $_ := set $cc "tool_execution_timeout" $client.toolExecutionTimeout }}
{{- end }}
{{- if hasKey $client "maxInstructionsLength" }}
{{- $_ := set $cc "max_instructions_length" $client.maxInstructionsLength }}
{{- end }}
{{- if hasKey $client "requirePublicTarget" }}
{{- $_ := set $cc "require_public_target" $client.requirePublicTarget }}
{{- end }}
{{- if $client.toolPricing }}
{{- $_ := set $cc "tool_pricing" $client.toolPricing }}
{{- end }}
{{- if $client.allowedExtraHeaders }}
{{- $_ := set $cc "allowed_extra_headers" $client.allowedExtraHeaders }}
{{- end }}
{{- if $client.perUserHeaderKeys }}
{{- $_ := set $cc "per_user_header_keys" $client.perUserHeaderKeys }}
{{- end }}
{{- /* allowByDefault supersedes allowOnAllVirtualKeys. Emit exactly one key so the backend's
       ResolveAllowByDefault sees an unambiguous declaration: the current key when it is given,
       otherwise the deprecated one passed through untranslated. */ -}}
{{- if hasKey $client "allowByDefault" }}
{{- $_ := set $cc "allow_by_default" $client.allowByDefault }}
{{- else if hasKey $client "allowOnAllVirtualKeys" }}
{{- $_ := set $cc "allow_on_all_virtual_keys" $client.allowOnAllVirtualKeys }}
{{- end }}
{{- if $client.endpointSlug }}
{{- $_ := set $cc "endpoint_slug" $client.endpointSlug }}
{{- end }}
{{- /* Map tlsConfig -> tls_config (only for http/sse/websocket connection types) */ -}}
{{- if and $client.tlsConfig (or (eq $client.connectionType "http") (eq $client.connectionType "sse") (eq $client.connectionType "websocket")) }}
{{- $tls := dict }}
{{- if hasKey $client.tlsConfig "insecureSkipVerify" }}
{{- $_ := set $tls "insecure_skip_verify" $client.tlsConfig.insecureSkipVerify }}
{{- end }}
{{- if $client.tlsConfig.caCertPem }}
{{- $_ := set $tls "ca_cert_pem" $client.tlsConfig.caCertPem }}
{{- end }}
{{- if $tls }}
{{- $_ := set $cc "tls_config" $tls }}
{{- end }}
{{- end }}
{{- /* Override connection_string with env var placeholder when secretRef is set */ -}}
{{- if and $client.secretRef $client.secretRef.name }}
{{- $envName := printf "BIFROST_MCP_%s_CONNECTION_STRING" (regexReplaceAll "[^A-Z0-9]+" (upper $client.name) "_") }}
{{- $_ := set $cc "connection_string" (printf "env.%s" $envName) }}
{{- end }}
{{- $clientConfigs = append $clientConfigs $cc }}
{{- end }}
{{- $mcpConfig := dict "client_configs" $clientConfigs }}
{{- if .Values.bifrost.mcp.toolManagerConfig }}
{{- $tmConfig := dict }}
{{- if .Values.bifrost.mcp.toolManagerConfig.toolExecutionTimeout }}
{{- $_ := set $tmConfig "tool_execution_timeout" .Values.bifrost.mcp.toolManagerConfig.toolExecutionTimeout }}
{{- end }}
{{- if .Values.bifrost.mcp.toolManagerConfig.maxAgentDepth }}
{{- $_ := set $tmConfig "max_agent_depth" .Values.bifrost.mcp.toolManagerConfig.maxAgentDepth }}
{{- end }}
{{- if .Values.bifrost.mcp.toolManagerConfig.codeModeBindingLevel }}
{{- $_ := set $tmConfig "code_mode_binding_level" .Values.bifrost.mcp.toolManagerConfig.codeModeBindingLevel }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp.toolManagerConfig "disableAutoToolInject" }}
{{- $_ := set $tmConfig "disable_auto_tool_inject" .Values.bifrost.mcp.toolManagerConfig.disableAutoToolInject }}
{{- end }}
{{- if .Values.bifrost.mcp.toolManagerConfig.maxInstructionsPerClient }}
{{- $_ := set $tmConfig "max_instructions_per_client" .Values.bifrost.mcp.toolManagerConfig.maxInstructionsPerClient }}
{{- end }}
{{- if .Values.bifrost.mcp.toolManagerConfig.maxInstructionsTotal }}
{{- $_ := set $tmConfig "max_instructions_total" .Values.bifrost.mcp.toolManagerConfig.maxInstructionsTotal }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp.toolManagerConfig "codeModeLimits" }}
{{- $limits := dict }}
{{- with .Values.bifrost.mcp.toolManagerConfig.codeModeLimits }}
{{- if .maxSourceBytes }}
{{- $_ := set $limits "max_source_bytes" .maxSourceBytes }}
{{- end }}
{{- if .maxSteps }}
{{- $_ := set $limits "max_steps" .maxSteps }}
{{- end }}
{{- if .maxMemoryBytes }}
{{- $_ := set $limits "max_memory_bytes" .maxMemoryBytes }}
{{- end }}
{{- if .maxLogBytes }}
{{- $_ := set $limits "max_log_bytes" .maxLogBytes }}
{{- end }}
{{- if .maxToolCalls }}
{{- $_ := set $limits "max_tool_calls" .maxToolCalls }}
{{- end }}
{{- if .maxValueBytes }}
{{- $_ := set $limits "max_value_bytes" .maxValueBytes }}
{{- end }}
{{- if .maxNestingDepth }}
{{- $_ := set $limits "max_nesting_depth" .maxNestingDepth }}
{{- end }}
{{- end }}
{{- /* Render the key even when every limit is 0, so an explicit setting resets stored limits to defaults. */}}
{{- $_ := set $tmConfig "code_mode_limits" $limits }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp.toolManagerConfig "oauthPrivateAllowlist" }}
{{- /* Render the key even when empty, so an explicit [] clears a stored allowlist. */}}
{{- $_ := set $tmConfig "oauth_private_allowlist" (.Values.bifrost.mcp.toolManagerConfig.oauthPrivateAllowlist | default list) }}
{{- end }}
{{- if $tmConfig }}
{{- $_ := set $mcpConfig "tool_manager_config" $tmConfig }}
{{- end }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp "toolSyncInterval" }}
{{- $_ := set $mcpConfig "tool_sync_interval" .Values.bifrost.mcp.toolSyncInterval }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp "toolGroups" }}
{{- $toolGroups := list }}
{{- range .Values.bifrost.mcp.toolGroups }}
{{- $group := dict "name" .name }}
{{- if .id }}{{- $_ := set $group "id" .id }}{{- end }}
{{- if hasKey . "enabled" }}{{- $_ := set $group "enabled" .enabled }}{{- end }}
{{- if .description }}{{- $_ := set $group "description" .description }}{{- end }}
{{- if .tools }}
{{- $tools := list }}
{{- range .tools }}
{{- $tool := dict }}
{{- if .mcpClientId }}{{- $_ := set $tool "mcp_client_id" .mcpClientId }}{{- end }}
{{- if .mcpClientName }}{{- $_ := set $tool "mcp_client_name" .mcpClientName }}{{- end }}
{{- if .toolNames }}{{- $_ := set $tool "tool_names" .toolNames }}{{- end }}
{{- $tools = append $tools $tool }}
{{- end }}
{{- $_ := set $group "tools" $tools }}
{{- end }}
{{- if .virtualKeyIds }}{{- $_ := set $group "virtual_key_ids" .virtualKeyIds }}{{- end }}
{{- if .teamIds }}{{- $_ := set $group "team_ids" .teamIds }}{{- end }}
{{- if .customerIds }}{{- $_ := set $group "customer_ids" .customerIds }}{{- end }}
{{- if .userIds }}{{- $_ := set $group "user_ids" .userIds }}{{- end }}
{{- if .providerNames }}{{- $_ := set $group "provider_names" .providerNames }}{{- end }}
{{- if .apiKeyIds }}{{- $_ := set $group "api_key_ids" .apiKeyIds }}{{- end }}
{{- $toolGroups = append $toolGroups $group }}
{{- end }}
{{- $_ := set $mcpConfig "tool_groups" $toolGroups }}
{{- end }}
{{- if hasKey .Values.bifrost.mcp "virtualMcps" }}
{{- $virtualMcps := list }}
{{- range .Values.bifrost.mcp.virtualMcps }}
{{- $vmcp := dict "name" .name }}
{{- if .id }}{{- $_ := set $vmcp "id" .id }}{{- end }}
{{- if .endpointSlug }}{{- $_ := set $vmcp "endpoint_slug" .endpointSlug }}{{- end }}
{{- if hasKey . "enabled" }}{{- $_ := set $vmcp "enabled" .enabled }}{{- end }}
{{- if .description }}{{- $_ := set $vmcp "description" .description }}{{- end }}
{{- if .tools }}
{{- $tools := list }}
{{- range .tools }}
{{- $tool := dict }}
{{- if .mcpClientId }}{{- $_ := set $tool "mcp_client_id" .mcpClientId }}{{- end }}
{{- if .mcpClientName }}{{- $_ := set $tool "mcp_client_name" .mcpClientName }}{{- end }}
{{- if .toolNames }}{{- $_ := set $tool "tool_names" .toolNames }}{{- end }}
{{- $tools = append $tools $tool }}
{{- end }}
{{- $_ := set $vmcp "tools" $tools }}
{{- end }}
{{- if .virtualKeyIds }}{{- $_ := set $vmcp "virtual_key_ids" .virtualKeyIds }}{{- end }}
{{- $virtualMcps = append $virtualMcps $vmcp }}
{{- end }}
{{- $_ := set $mcpConfig "virtual_mcps" $virtualMcps }}
{{- end }}
{{- $_ := set $config "mcp" $mcpConfig }}
{{- end }}
{{- /* Plugins - as array per schema */ -}}
{{- $plugins := list }}
{{- if .Values.bifrost.plugins.telemetry.enabled }}
{{- $plugin := dict "enabled" true "name" "telemetry" "config" .Values.bifrost.plugins.telemetry.config }}
{{- if hasKey .Values.bifrost.plugins.telemetry "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.telemetry.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.logging.enabled }}
{{- $plugin := dict "enabled" true "name" "logging" "config" .Values.bifrost.plugins.logging.config }}
{{- if hasKey .Values.bifrost.plugins.logging "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.logging.version | int) }}{{- end }}
{{- if .Values.bifrost.plugins.logging.semaphore_size }}
{{- $_ := set $plugin "semaphore_size" (.Values.bifrost.plugins.logging.semaphore_size | int) }}
{{- end }}
{{- if .Values.bifrost.plugins.logging.inject_timeout }}
{{- $_ := set $plugin "inject_timeout" .Values.bifrost.plugins.logging.inject_timeout }}
{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.governance.enabled }}
{{- $governanceConfig := dict }}
{{- if hasKey .Values.bifrost.plugins.governance.config "is_vk_mandatory" }}
{{- $_ := set $governanceConfig "is_vk_mandatory" .Values.bifrost.plugins.governance.config.is_vk_mandatory }}
{{- end }}
{{- if .Values.bifrost.plugins.governance.config.required_headers }}
{{- $_ := set $governanceConfig "required_headers" .Values.bifrost.plugins.governance.config.required_headers }}
{{- end }}
{{- if hasKey .Values.bifrost.plugins.governance.config "is_enterprise" }}
{{- $_ := set $governanceConfig "is_enterprise" .Values.bifrost.plugins.governance.config.is_enterprise }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "governance" "config" $governanceConfig }}
{{- if hasKey .Values.bifrost.plugins.governance "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.governance.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.maxim.enabled }}
{{- $maximConfig := dict }}
{{- if and .Values.bifrost.plugins.maxim.secretRef .Values.bifrost.plugins.maxim.secretRef.name }}
{{- $_ := set $maximConfig "api_key" "env.BIFROST_MAXIM_API_KEY" }}
{{- else if .Values.bifrost.plugins.maxim.config.api_key }}
{{- $_ := set $maximConfig "api_key" .Values.bifrost.plugins.maxim.config.api_key }}
{{- end }}
{{- if .Values.bifrost.plugins.maxim.config.log_repo_id }}
{{- $_ := set $maximConfig "log_repo_id" .Values.bifrost.plugins.maxim.config.log_repo_id }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "maxim" "config" $maximConfig }}
{{- if hasKey .Values.bifrost.plugins.maxim "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.maxim.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.semanticCache.enabled }}
{{- $scConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.semanticCache.config | default dict }}
{{- if $inputConfig.dimension }}
{{- $_ := set $scConfig "dimension" $inputConfig.dimension }}
{{- end }}
{{/* Only include embedding provider config when not in direct cache mode (dimension: 1) */}}
{{- if ne (int ($inputConfig.dimension | default 1536)) 1 }}
{{- if $inputConfig.provider }}
{{- $_ := set $scConfig "provider" $inputConfig.provider }}
{{- end }}
{{- if $inputConfig.embedding_model }}
{{- $_ := set $scConfig "embedding_model" $inputConfig.embedding_model }}
{{- end }}
{{- end }}
{{- if $inputConfig.threshold }}
{{- $_ := set $scConfig "threshold" $inputConfig.threshold }}
{{- end }}
{{- if $inputConfig.ttl }}
{{- $_ := set $scConfig "ttl" $inputConfig.ttl }}
{{- end }}
{{- if $inputConfig.vector_store_namespace }}
{{- $_ := set $scConfig "vector_store_namespace" $inputConfig.vector_store_namespace }}
{{- end }}
{{- if $inputConfig.default_cache_key }}
{{- $_ := set $scConfig "default_cache_key" $inputConfig.default_cache_key }}
{{- end }}
{{- if hasKey $inputConfig "conversation_history_threshold" }}
{{- $_ := set $scConfig "conversation_history_threshold" $inputConfig.conversation_history_threshold }}
{{- end }}
{{- if hasKey $inputConfig "cache_by_model" }}
{{- $_ := set $scConfig "cache_by_model" $inputConfig.cache_by_model }}
{{- end }}
{{- if hasKey $inputConfig "cache_by_provider" }}
{{- $_ := set $scConfig "cache_by_provider" $inputConfig.cache_by_provider }}
{{- end }}
{{- if hasKey $inputConfig "exclude_system_prompt" }}
{{- $_ := set $scConfig "exclude_system_prompt" $inputConfig.exclude_system_prompt }}
{{- end }}
{{- if hasKey $inputConfig "cache_tool_call_responses" }}
{{- $_ := set $scConfig "cache_tool_call_responses" $inputConfig.cache_tool_call_responses }}
{{- end }}
{{- if hasKey $inputConfig "disable_identity_scoping" }}
{{- $_ := set $scConfig "disable_identity_scoping" $inputConfig.disable_identity_scoping }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "semantic_cache" "config" $scConfig }}
{{- if hasKey .Values.bifrost.plugins.semanticCache "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.semanticCache.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.otel.enabled }}
{{- $otelConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.otel.config | default dict }}
{{- if hasKey $inputConfig "profiles" }}
{{- $_ := set $otelConfig "profiles" $inputConfig.profiles }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $otelConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- else }}
{{- if $inputConfig.service_name }}
{{- $_ := set $otelConfig "service_name" $inputConfig.service_name }}
{{- end }}
{{- if hasKey $inputConfig "traces_enabled" }}
{{- $_ := set $otelConfig "traces_enabled" $inputConfig.traces_enabled }}
{{- end }}
{{- if $inputConfig.collector_url }}
{{- $_ := set $otelConfig "collector_url" $inputConfig.collector_url }}
{{- end }}
{{- if $inputConfig.trace_type }}
{{- $_ := set $otelConfig "trace_type" $inputConfig.trace_type }}
{{- end }}
{{- if $inputConfig.protocol }}
{{- $_ := set $otelConfig "protocol" $inputConfig.protocol }}
{{- end }}
{{- if $inputConfig.export_timeout }}
{{- $_ := set $otelConfig "export_timeout" ($inputConfig.export_timeout | int) }}
{{- end }}
{{- if hasKey $inputConfig "metrics_enabled" }}
{{- $_ := set $otelConfig "metrics_enabled" $inputConfig.metrics_enabled }}
{{- end }}
{{- if $inputConfig.metrics_endpoint }}
{{- $_ := set $otelConfig "metrics_endpoint" $inputConfig.metrics_endpoint }}
{{- end }}
{{- if $inputConfig.metrics_push_interval }}
{{- $_ := set $otelConfig "metrics_push_interval" $inputConfig.metrics_push_interval }}
{{- end }}
{{- if $inputConfig.headers }}
{{- $_ := set $otelConfig "headers" $inputConfig.headers }}
{{- end }}
{{- if $inputConfig.trace_headers }}
{{- $_ := set $otelConfig "trace_headers" $inputConfig.trace_headers }}
{{- end }}
{{- if $inputConfig.metrics_headers }}
{{- $_ := set $otelConfig "metrics_headers" $inputConfig.metrics_headers }}
{{- end }}
{{- if $inputConfig.tls_ca_cert }}
{{- $_ := set $otelConfig "tls_ca_cert" $inputConfig.tls_ca_cert }}
{{- end }}
{{- if hasKey $inputConfig "insecure" }}
{{- $_ := set $otelConfig "insecure" $inputConfig.insecure }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $otelConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if hasKey $inputConfig "group_traces_by_session" }}
{{- $_ := set $otelConfig "group_traces_by_session" $inputConfig.group_traces_by_session }}
{{- end }}
{{- if hasKey $inputConfig "disable_root_span_content" }}
{{- $_ := set $otelConfig "disable_root_span_content" $inputConfig.disable_root_span_content }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $otelConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $otelConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if hasKey $inputConfig "export_raw_payloads" }}
{{- $_ := set $otelConfig "export_raw_payloads" $inputConfig.export_raw_payloads }}
{{- end }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $otelConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- if hasKey $inputConfig "export_overhead_spans" }}
{{- $_ := set $otelConfig "export_overhead_spans" $inputConfig.export_overhead_spans }}
{{- end }}
{{- if hasKey $inputConfig "overhead_breakdown_enabled" }}
{{- $_ := set $otelConfig "overhead_breakdown_enabled" $inputConfig.overhead_breakdown_enabled }}
{{- end }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "otel" "config" $otelConfig }}
{{- if hasKey .Values.bifrost.plugins.otel "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.otel.version | int) }}{{- end }}
{{- if .Values.bifrost.plugins.otel.semaphore_size }}
{{- $_ := set $plugin "semaphore_size" (.Values.bifrost.plugins.otel.semaphore_size | int) }}
{{- end }}
{{- if .Values.bifrost.plugins.otel.inject_timeout }}
{{- $_ := set $plugin "inject_timeout" .Values.bifrost.plugins.otel.inject_timeout }}
{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.datadog.enabled }}
{{- $datadogConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.datadog.config | default dict }}
{{- if $inputConfig.service_name }}
{{- $_ := set $datadogConfig "service_name" $inputConfig.service_name }}
{{- end }}
{{- if $inputConfig.ml_app }}
{{- $_ := set $datadogConfig "ml_app" $inputConfig.ml_app }}
{{- end }}
{{- if $inputConfig.agent_addr }}
{{- $_ := set $datadogConfig "agent_addr" $inputConfig.agent_addr }}
{{- end }}
{{- if $inputConfig.agent_host }}
{{- $_ := set $datadogConfig "agent_host" $inputConfig.agent_host }}
{{- end }}
{{- if $inputConfig.agent_port }}
{{- $_ := set $datadogConfig "agent_port" $inputConfig.agent_port }}
{{- end }}
{{- if $inputConfig.dogstatsd_addr }}
{{- $_ := set $datadogConfig "dogstatsd_addr" $inputConfig.dogstatsd_addr }}
{{- end }}
{{- if $inputConfig.dogstatsd_host }}
{{- $_ := set $datadogConfig "dogstatsd_host" $inputConfig.dogstatsd_host }}
{{- end }}
{{- if $inputConfig.dogstatsd_port }}
{{- $_ := set $datadogConfig "dogstatsd_port" $inputConfig.dogstatsd_port }}
{{- end }}
{{- if $inputConfig.env }}
{{- $_ := set $datadogConfig "env" $inputConfig.env }}
{{- end }}
{{- if $inputConfig.version }}
{{- $_ := set $datadogConfig "version" $inputConfig.version }}
{{- end }}
{{- if $inputConfig.custom_tags }}
{{- $_ := set $datadogConfig "custom_tags" $inputConfig.custom_tags }}
{{- end }}
{{- if hasKey $inputConfig "enable_metrics" }}
{{- $_ := set $datadogConfig "enable_metrics" $inputConfig.enable_metrics }}
{{- end }}
{{- if hasKey $inputConfig "enable_traces" }}
{{- $_ := set $datadogConfig "enable_traces" $inputConfig.enable_traces }}
{{- end }}
{{- if hasKey $inputConfig "enable_llm_obs" }}
{{- $_ := set $datadogConfig "enable_llm_obs" $inputConfig.enable_llm_obs }}
{{- end }}
{{- if $inputConfig.otel_llmobs_conversion }}
{{- $_ := set $datadogConfig "otel_llmobs_conversion" $inputConfig.otel_llmobs_conversion }}
{{- end }}
{{- if hasKey $inputConfig "llmobs_gateway_mode" }}
{{- $_ := set $datadogConfig "llmobs_gateway_mode" $inputConfig.llmobs_gateway_mode }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $datadogConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if hasKey $inputConfig "group_traces_by_session" }}
{{- $_ := set $datadogConfig "group_traces_by_session" $inputConfig.group_traces_by_session }}
{{- end }}
{{- if hasKey $inputConfig "agentless" }}
{{- $_ := set $datadogConfig "agentless" $inputConfig.agentless }}
{{- end }}
{{- if $inputConfig.api_key }}
{{- $_ := set $datadogConfig "api_key" $inputConfig.api_key }}
{{- end }}
{{- if $inputConfig.site }}
{{- $_ := set $datadogConfig "site" $inputConfig.site }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $datadogConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $datadogConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if hasKey $inputConfig "metric_dimensions" }}
{{- $_ := set $datadogConfig "metric_dimensions" $inputConfig.metric_dimensions }}
{{- end }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $datadogConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "datadog" "config" $datadogConfig }}
{{- if hasKey .Values.bifrost.plugins.datadog "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.datadog.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.bigquery.enabled }}
{{- $bigqueryConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.bigquery.config | default dict }}
{{- if $inputConfig.project_id }}
{{- $_ := set $bigqueryConfig "project_id" $inputConfig.project_id }}
{{- end }}
{{- if $inputConfig.dataset_id }}
{{- $_ := set $bigqueryConfig "dataset_id" $inputConfig.dataset_id }}
{{- end }}
{{- if $inputConfig.table_id }}
{{- $_ := set $bigqueryConfig "table_id" $inputConfig.table_id }}
{{- end }}
{{- if $inputConfig.location }}
{{- $_ := set $bigqueryConfig "location" $inputConfig.location }}
{{- end }}
{{- if $inputConfig.service_account_key }}
{{- $_ := set $bigqueryConfig "service_account_key" $inputConfig.service_account_key }}
{{- end }}
{{- if hasKey $inputConfig "create_table_if_not_exists" }}
{{- $_ := set $bigqueryConfig "create_table_if_not_exists" $inputConfig.create_table_if_not_exists }}
{{- end }}
{{- if hasKey $inputConfig "flush_interval_seconds" }}
{{- $_ := set $bigqueryConfig "flush_interval_seconds" $inputConfig.flush_interval_seconds }}
{{- end }}
{{- if hasKey $inputConfig "buffer_size" }}
{{- $_ := set $bigqueryConfig "buffer_size" $inputConfig.buffer_size }}
{{- end }}
{{- if $inputConfig.custom_labels }}
{{- $_ := set $bigqueryConfig "custom_labels" $inputConfig.custom_labels }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $bigqueryConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $bigqueryConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $bigqueryConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if hasKey $inputConfig "export_raw_payloads" }}
{{- $_ := set $bigqueryConfig "export_raw_payloads" $inputConfig.export_raw_payloads }}
{{- end }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $bigqueryConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "bigquery" "config" $bigqueryConfig }}
{{- if hasKey .Values.bifrost.plugins.bigquery "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.bigquery.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if (.Values.bifrost.plugins.kafka).enabled }}
{{- $kafkaConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.kafka.config | default dict }}
{{- if $inputConfig.brokers }}
{{- $_ := set $kafkaConfig "brokers" $inputConfig.brokers }}
{{- end }}
{{- if $inputConfig.topic }}
{{- $_ := set $kafkaConfig "topic" $inputConfig.topic }}
{{- end }}
{{- if hasKey $inputConfig "sasl_enabled" }}
{{- $_ := set $kafkaConfig "sasl_enabled" $inputConfig.sasl_enabled }}
{{- end }}
{{- if $inputConfig.sasl }}
{{- $_ := set $kafkaConfig "sasl" $inputConfig.sasl }}
{{- end }}
{{- if hasKey $inputConfig "tls_enabled" }}
{{- $_ := set $kafkaConfig "tls_enabled" $inputConfig.tls_enabled }}
{{- end }}
{{- if $inputConfig.ca_cert }}
{{- $_ := set $kafkaConfig "ca_cert" $inputConfig.ca_cert }}
{{- end }}
{{- if $inputConfig.compression }}
{{- $_ := set $kafkaConfig "compression" $inputConfig.compression }}
{{- end }}
{{- if hasKey $inputConfig "batch_size" }}
{{- $_ := set $kafkaConfig "batch_size" $inputConfig.batch_size }}
{{- end }}
{{- if hasKey $inputConfig "flush_interval_ms" }}
{{- $_ := set $kafkaConfig "flush_interval_ms" $inputConfig.flush_interval_ms }}
{{- end }}
{{- if hasKey $inputConfig "auto_create_topic" }}
{{- $_ := set $kafkaConfig "auto_create_topic" $inputConfig.auto_create_topic }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $kafkaConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $kafkaConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $kafkaConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $kafkaConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "kafka" "config" $kafkaConfig }}
{{- if hasKey .Values.bifrost.plugins.kafka "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.kafka.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if (.Values.bifrost.plugins.pubsub).enabled }}
{{- $pubsubConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.pubsub.config | default dict }}
{{- if $inputConfig.project_id }}
{{- $_ := set $pubsubConfig "project_id" $inputConfig.project_id }}
{{- end }}
{{- if $inputConfig.topic_id }}
{{- $_ := set $pubsubConfig "topic_id" $inputConfig.topic_id }}
{{- end }}
{{- if $inputConfig.service_account_key }}
{{- $_ := set $pubsubConfig "service_account_key" $inputConfig.service_account_key }}
{{- end }}
{{- if hasKey $inputConfig "auto_create_topic" }}
{{- $_ := set $pubsubConfig "auto_create_topic" $inputConfig.auto_create_topic }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $pubsubConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $pubsubConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $pubsubConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if $inputConfig.plugin_span_filter }}
{{- $_ := set $pubsubConfig "plugin_span_filter" $inputConfig.plugin_span_filter }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "pubsub" "config" $pubsubConfig }}
{{- if hasKey .Values.bifrost.plugins.pubsub "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.pubsub.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- if .Values.bifrost.plugins.splunk.enabled }}
{{- $splunkConfig := dict }}
{{- $inputConfig := .Values.bifrost.plugins.splunk.config | default dict }}
{{- if $inputConfig.endpoint }}
{{- $_ := set $splunkConfig "endpoint" $inputConfig.endpoint }}
{{- end }}
{{- if $inputConfig.token }}
{{- $_ := set $splunkConfig "token" $inputConfig.token }}
{{- end }}
{{- if $inputConfig.events_index }}
{{- $_ := set $splunkConfig "events_index" $inputConfig.events_index }}
{{- end }}
{{- if $inputConfig.metrics_index }}
{{- $_ := set $splunkConfig "metrics_index" $inputConfig.metrics_index }}
{{- end }}
{{- if $inputConfig.source }}
{{- $_ := set $splunkConfig "source" $inputConfig.source }}
{{- end }}
{{- if $inputConfig.sourcetype }}
{{- $_ := set $splunkConfig "sourcetype" $inputConfig.sourcetype }}
{{- end }}
{{- if $inputConfig.host }}
{{- $_ := set $splunkConfig "host" $inputConfig.host }}
{{- end }}
{{- if hasKey $inputConfig "enable_events" }}
{{- $_ := set $splunkConfig "enable_events" $inputConfig.enable_events }}
{{- end }}
{{- if hasKey $inputConfig "enable_metrics" }}
{{- $_ := set $splunkConfig "enable_metrics" $inputConfig.enable_metrics }}
{{- end }}
{{- if hasKey $inputConfig "disable_content_logging" }}
{{- $_ := set $splunkConfig "disable_content_logging" $inputConfig.disable_content_logging }}
{{- end }}
{{- if $inputConfig.ca_cert }}
{{- $_ := set $splunkConfig "ca_cert" $inputConfig.ca_cert }}
{{- end }}
{{- if hasKey $inputConfig "insecure_skip_verify" }}
{{- $_ := set $splunkConfig "insecure_skip_verify" $inputConfig.insecure_skip_verify }}
{{- end }}
{{- if $inputConfig.custom_fields }}
{{- $_ := set $splunkConfig "custom_fields" $inputConfig.custom_fields }}
{{- end }}
{{- if hasKey $inputConfig "request_headers" }}
{{- $_ := set $splunkConfig "request_headers" $inputConfig.request_headers }}
{{- end }}
{{- if hasKey $inputConfig "excluded_attributes" }}
{{- $_ := set $splunkConfig "excluded_attributes" $inputConfig.excluded_attributes }}
{{- end }}
{{- if $inputConfig.batch_max_bytes }}
{{- $_ := set $splunkConfig "batch_max_bytes" (int $inputConfig.batch_max_bytes) }}
{{- end }}
{{- if $inputConfig.flush_interval_ms }}
{{- $_ := set $splunkConfig "flush_interval_ms" (int $inputConfig.flush_interval_ms) }}
{{- end }}
{{- if $inputConfig.post_workers }}
{{- $_ := set $splunkConfig "post_workers" (int $inputConfig.post_workers) }}
{{- end }}
{{- if hasKey $inputConfig "indexer_ack" }}
{{- $_ := set $splunkConfig "indexer_ack" $inputConfig.indexer_ack }}
{{- end }}
{{- if $inputConfig.ack_poll_interval_ms }}
{{- $_ := set $splunkConfig "ack_poll_interval_ms" (int $inputConfig.ack_poll_interval_ms) }}
{{- end }}
{{- if $inputConfig.ack_timeout_ms }}
{{- $_ := set $splunkConfig "ack_timeout_ms" (int $inputConfig.ack_timeout_ms) }}
{{- end }}
{{- if $inputConfig.max_ack_attempts }}
{{- $_ := set $splunkConfig "max_ack_attempts" (int $inputConfig.max_ack_attempts) }}
{{- end }}
{{- $plugin := dict "enabled" true "name" "splunk" "config" $splunkConfig }}
{{- if hasKey .Values.bifrost.plugins.splunk "version" }}{{- $_ := set $plugin "version" (.Values.bifrost.plugins.splunk.version | int) }}{{- end }}
{{- $plugins = append $plugins $plugin }}
{{- end }}
{{- /* Custom plugins */ -}}
{{- if .Values.bifrost.plugins.custom }}
{{- range .Values.bifrost.plugins.custom }}
{{- $customPlugin := dict "enabled" .enabled "name" .name }}
{{- if .path }}{{- $_ := set $customPlugin "path" .path }}{{- end }}
{{- if hasKey . "version" }}{{- $_ := set $customPlugin "version" (.version | int) }}{{- end }}
{{- if .config }}{{- $_ := set $customPlugin "config" .config }}{{- end }}
{{- if .placement }}{{- $_ := set $customPlugin "placement" .placement }}{{- end }}
{{- if .order }}{{- $_ := set $customPlugin "order" (.order | int) }}{{- end }}
{{- if .semaphore_size }}{{- $_ := set $customPlugin "semaphore_size" (.semaphore_size | int) }}{{- end }}
{{- if .inject_timeout }}{{- $_ := set $customPlugin "inject_timeout" .inject_timeout }}{{- end }}
{{- $plugins = append $plugins $customPlugin }}
{{- end }}
{{- end }}
{{- if $plugins }}
{{- $_ := set $config "plugins" $plugins }}
{{- end }}
{{- /* Audit Logs */ -}}
{{- if .Values.bifrost.auditLogs }}
{{- $auditLogs := dict }}
{{- if hasKey .Values.bifrost.auditLogs "disabled" }}
{{- $_ := set $auditLogs "disabled" .Values.bifrost.auditLogs.disabled }}
{{- end }}
{{- if .Values.bifrost.auditLogs.hmacKey }}
{{- $_ := set $auditLogs "hmac_key" .Values.bifrost.auditLogs.hmacKey }}
{{- end }}
{{- if .Values.bifrost.auditLogs.omitIpAddresses }}
{{- $_ := set $auditLogs "omit_ip_addresses" true }}
{{- end }}
{{- if .Values.bifrost.auditLogs.archiveInterval }}
{{- $_ := set $auditLogs "archive_interval" .Values.bifrost.auditLogs.archiveInterval }}
{{- end }}
{{- if .Values.bifrost.auditLogs.archiveGracePeriod }}
{{- $_ := set $auditLogs "archive_grace_period" .Values.bifrost.auditLogs.archiveGracePeriod }}
{{- end }}
{{- if .Values.bifrost.auditLogs.archiveMaxObjectBytes }}
{{- $_ := set $auditLogs "archive_max_object_bytes" (int64 .Values.bifrost.auditLogs.archiveMaxObjectBytes) }}
{{- end }}
{{- if .Values.bifrost.auditLogs.objectStorage }}
{{- $aos := .Values.bifrost.auditLogs.objectStorage }}
{{- $aosConfig := dict "type" $aos.type "bucket" $aos.bucket }}
{{- if $aos.prefix }}
{{- $_ := set $aosConfig "prefix" $aos.prefix }}
{{- end }}
{{- if $aos.compress }}
{{- $_ := set $aosConfig "compress" true }}
{{- end }}
{{- if eq $aos.type "s3" }}
{{- if $aos.region }}
{{- $_ := set $aosConfig "region" $aos.region }}
{{- end }}
{{- if $aos.endpoint }}
{{- $_ := set $aosConfig "endpoint" $aos.endpoint }}
{{- end }}
{{- if $aos.accessKeyId }}
{{- $_ := set $aosConfig "access_key_id" $aos.accessKeyId }}
{{- end }}
{{- if $aos.secretAccessKey }}
{{- $_ := set $aosConfig "secret_access_key" $aos.secretAccessKey }}
{{- end }}
{{- if $aos.sessionToken }}
{{- $_ := set $aosConfig "session_token" $aos.sessionToken }}
{{- end }}
{{- if $aos.roleArn }}
{{- $_ := set $aosConfig "role_arn" $aos.roleArn }}
{{- end }}
{{- if $aos.forcePathStyle }}
{{- $_ := set $aosConfig "force_path_style" true }}
{{- end }}
{{- end }}
{{- if eq $aos.type "gcs" }}
{{- if $aos.projectId }}
{{- $_ := set $aosConfig "project_id" $aos.projectId }}
{{- end }}
{{- if $aos.credentialsJson }}
{{- $_ := set $aosConfig "credentials_json" $aos.credentialsJson }}
{{- end }}
{{- end }}
{{- $_ := set $auditLogs "object_storage" $aosConfig }}
{{- end }}
{{- if or (hasKey $auditLogs "disabled") $auditLogs.hmac_key $auditLogs.object_storage }}
{{- $_ := set $config "audit_logs" $auditLogs }}
{{- end }}
{{- end }}
{{- /* Large Payload Optimization */ -}}
{{- if .Values.bifrost.largePayloadOptimization }}
{{- $lpo := dict }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "enabled" }}
{{- $_ := set $lpo "enabled" .Values.bifrost.largePayloadOptimization.enabled }}
{{- end }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "requestThresholdBytes" }}
{{- $_ := set $lpo "request_threshold_bytes" .Values.bifrost.largePayloadOptimization.requestThresholdBytes }}
{{- end }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "responseThresholdBytes" }}
{{- $_ := set $lpo "response_threshold_bytes" .Values.bifrost.largePayloadOptimization.responseThresholdBytes }}
{{- end }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "prefetchSizeBytes" }}
{{- $_ := set $lpo "prefetch_size_bytes" .Values.bifrost.largePayloadOptimization.prefetchSizeBytes }}
{{- end }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "maxPayloadBytes" }}
{{- $_ := set $lpo "max_payload_bytes" .Values.bifrost.largePayloadOptimization.maxPayloadBytes }}
{{- end }}
{{- if hasKey .Values.bifrost.largePayloadOptimization "truncatedLogBytes" }}
{{- $_ := set $lpo "truncated_log_bytes" .Values.bifrost.largePayloadOptimization.truncatedLogBytes }}
{{- end }}
{{- if $lpo }}
{{- $_ := set $config "large_payload_optimization" $lpo }}
{{- end }}
{{- end }}
{{- /* WebSocket Config */ -}}
{{- if .Values.bifrost.websocket }}
{{- $ws := dict }}
{{- if .Values.bifrost.websocket.maxConnectionsPerUser }}
{{- $_ := set $ws "max_connections_per_user" .Values.bifrost.websocket.maxConnectionsPerUser }}
{{- end }}
{{- if .Values.bifrost.websocket.transcriptBufferSize }}
{{- $_ := set $ws "transcript_buffer_size" .Values.bifrost.websocket.transcriptBufferSize }}
{{- end }}
{{- if .Values.bifrost.websocket.pool }}
{{- $pool := dict }}
{{- if .Values.bifrost.websocket.pool.maxIdlePerKey }}
{{- $_ := set $pool "max_idle_per_key" .Values.bifrost.websocket.pool.maxIdlePerKey }}
{{- end }}
{{- if .Values.bifrost.websocket.pool.maxTotalConnections }}
{{- $_ := set $pool "max_total_connections" .Values.bifrost.websocket.pool.maxTotalConnections }}
{{- end }}
{{- if .Values.bifrost.websocket.pool.idleTimeoutSeconds }}
{{- $_ := set $pool "idle_timeout_seconds" .Values.bifrost.websocket.pool.idleTimeoutSeconds }}
{{- end }}
{{- if .Values.bifrost.websocket.pool.maxConnectionLifetimeSeconds }}
{{- $_ := set $pool "max_connection_lifetime_seconds" .Values.bifrost.websocket.pool.maxConnectionLifetimeSeconds }}
{{- end }}
{{- if $pool }}
{{- $_ := set $ws "pool" $pool }}
{{- end }}
{{- end }}
{{- if $ws }}
{{- $_ := set $config "websocket" $ws }}
{{- end }}
{{- end }}
{{- if .Values.bifrost.featureFlags }}
{{- $flags := dict }}
{{- range $name, $cfg := .Values.bifrost.featureFlags }}
{{- if not (kindIs "map" $cfg) }}
{{- fail (printf "ERROR: bifrost.featureFlags.%s must be an object with an 'enabled' field." $name) }}
{{- end }}
{{- if not (hasKey $cfg "enabled") }}
{{- fail (printf "ERROR: bifrost.featureFlags.%s.enabled is required." $name) }}
{{- end }}
{{- $_ := set $flags $name (dict "enabled" $cfg.enabled) }}
{{- end }}
{{- if $flags }}
{{- $_ := set $config "feature_flags" (dict "flags" $flags) }}
{{- end }}
{{- end }}
{{- /* Circuit Breaker Config */ -}}
{{- if .Values.bifrost.circuitBreakerConfig }}
{{- $_ := set $config "circuit_breaker_config" .Values.bifrost.circuitBreakerConfig }}
{{- end }}
{{- $config | toJson }}
{{- end }}

{{/*
Validation template - validates required fields from config.schema.json
Call this template at the beginning of deployment/stateful templates
*/}}
{{- define "bifrost.validate" -}}

{{/* Validate bifrost.sourceOfTruth enum */}}
{{- if .Values.bifrost.sourceOfTruth }}
{{- if and (ne .Values.bifrost.sourceOfTruth "split") (ne .Values.bifrost.sourceOfTruth "config.json") }}
{{- fail (printf "ERROR: bifrost.sourceOfTruth must be 'split' or 'config.json', got: %s" .Values.bifrost.sourceOfTruth) }}
{{- end }}
{{- end }}

{{/* Validate semantic cache plugin when enabled */}}
{{- if and .Values.bifrost.plugins.telemetry.enabled (hasKey .Values.bifrost.plugins.telemetry "version") (lt (int .Values.bifrost.plugins.telemetry.version) 1) }}
{{- fail "ERROR: bifrost.plugins.telemetry.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.telemetry.enabled (hasKey .Values.bifrost.plugins.telemetry "version") (gt (int .Values.bifrost.plugins.telemetry.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.telemetry.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.logging.enabled (hasKey .Values.bifrost.plugins.logging "version") (lt (int .Values.bifrost.plugins.logging.version) 1) }}
{{- fail "ERROR: bifrost.plugins.logging.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.logging.enabled (hasKey .Values.bifrost.plugins.logging "version") (gt (int .Values.bifrost.plugins.logging.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.logging.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.governance.enabled (hasKey .Values.bifrost.plugins.governance "version") (lt (int .Values.bifrost.plugins.governance.version) 1) }}
{{- fail "ERROR: bifrost.plugins.governance.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.governance.enabled (hasKey .Values.bifrost.plugins.governance "version") (gt (int .Values.bifrost.plugins.governance.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.governance.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.maxim.enabled (hasKey .Values.bifrost.plugins.maxim "version") (lt (int .Values.bifrost.plugins.maxim.version) 1) }}
{{- fail "ERROR: bifrost.plugins.maxim.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.maxim.enabled (hasKey .Values.bifrost.plugins.maxim "version") (gt (int .Values.bifrost.plugins.maxim.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.maxim.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.semanticCache.enabled (hasKey .Values.bifrost.plugins.semanticCache "version") (lt (int .Values.bifrost.plugins.semanticCache.version) 1) }}
{{- fail "ERROR: bifrost.plugins.semanticCache.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.semanticCache.enabled (hasKey .Values.bifrost.plugins.semanticCache "version") (gt (int .Values.bifrost.plugins.semanticCache.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.semanticCache.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.otel.enabled (hasKey .Values.bifrost.plugins.otel "version") (lt (int .Values.bifrost.plugins.otel.version) 1) }}
{{- fail "ERROR: bifrost.plugins.otel.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.otel.enabled (hasKey .Values.bifrost.plugins.otel "version") (gt (int .Values.bifrost.plugins.otel.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.otel.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.datadog.enabled (hasKey .Values.bifrost.plugins.datadog "version") (lt (int .Values.bifrost.plugins.datadog.version) 1) }}
{{- fail "ERROR: bifrost.plugins.datadog.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.datadog.enabled (hasKey .Values.bifrost.plugins.datadog "version") (gt (int .Values.bifrost.plugins.datadog.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.datadog.version must be <= 32767." }}
{{- end }}
{{- $ddCfg := (.Values.bifrost.plugins.datadog.config | default dict) }}
{{- if and .Values.bifrost.plugins.datadog.enabled $ddCfg.agentless (not $ddCfg.api_key) }}
{{- fail "ERROR: bifrost.plugins.datadog.config.api_key is required when bifrost.plugins.datadog.config.agentless is true." }}
{{- end }}
{{- if and .Values.bifrost.plugins.bigquery.enabled (hasKey .Values.bifrost.plugins.bigquery "version") (lt (int .Values.bifrost.plugins.bigquery.version) 1) }}
{{- fail "ERROR: bifrost.plugins.bigquery.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and .Values.bifrost.plugins.bigquery.enabled (hasKey .Values.bifrost.plugins.bigquery "version") (gt (int .Values.bifrost.plugins.bigquery.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.bigquery.version must be <= 32767." }}
{{- end }}
{{- if and .Values.bifrost.plugins.bigquery.enabled (not (.Values.bifrost.plugins.bigquery.config | default dict).project_id) }}
{{- fail "ERROR: bifrost.plugins.bigquery.config.project_id is required when the BigQuery plugin is enabled." }}
{{- end }}
{{- if and (.Values.bifrost.plugins.kafka).enabled (hasKey .Values.bifrost.plugins.kafka "version") (lt (int .Values.bifrost.plugins.kafka.version) 1) }}
{{- fail "ERROR: bifrost.plugins.kafka.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and (.Values.bifrost.plugins.kafka).enabled (hasKey .Values.bifrost.plugins.kafka "version") (gt (int .Values.bifrost.plugins.kafka.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.kafka.version must be <= 32767." }}
{{- end }}
{{- if (.Values.bifrost.plugins.kafka).enabled }}
{{- $kafkaInputConfig := .Values.bifrost.plugins.kafka.config | default dict }}
{{- if not $kafkaInputConfig.brokers }}
{{- fail "ERROR: bifrost.plugins.kafka.config.brokers is required when the Kafka plugin is enabled." }}
{{- end }}
{{- if not $kafkaInputConfig.topic }}
{{- fail "ERROR: bifrost.plugins.kafka.config.topic is required when the Kafka plugin is enabled." }}
{{- end }}
{{- end }}
{{- if and (.Values.bifrost.plugins.pubsub).enabled (hasKey .Values.bifrost.plugins.pubsub "version") (lt (int .Values.bifrost.plugins.pubsub.version) 1) }}
{{- fail "ERROR: bifrost.plugins.pubsub.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and (.Values.bifrost.plugins.pubsub).enabled (hasKey .Values.bifrost.plugins.pubsub "version") (gt (int .Values.bifrost.plugins.pubsub.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.pubsub.version must be <= 32767." }}
{{- end }}
{{- if (.Values.bifrost.plugins.pubsub).enabled }}
{{- $pubsubInputConfig := .Values.bifrost.plugins.pubsub.config | default dict }}
{{- if not $pubsubInputConfig.project_id }}
{{- fail "ERROR: bifrost.plugins.pubsub.config.project_id is required when the Pub/Sub plugin is enabled." }}
{{- end }}
{{- if not $pubsubInputConfig.topic_id }}
{{- fail "ERROR: bifrost.plugins.pubsub.config.topic_id is required when the Pub/Sub plugin is enabled." }}
{{- end }}
{{- end }}
{{- if and (.Values.bifrost.plugins.splunk).enabled (hasKey .Values.bifrost.plugins.splunk "version") (lt (int .Values.bifrost.plugins.splunk.version) 1) }}
{{- fail "ERROR: bifrost.plugins.splunk.version must be >= 1. Bump to >1 to force DB-backed plugin config updates." }}
{{- end }}
{{- if and (.Values.bifrost.plugins.splunk).enabled (hasKey .Values.bifrost.plugins.splunk "version") (gt (int .Values.bifrost.plugins.splunk.version) 32767) }}
{{- fail "ERROR: bifrost.plugins.splunk.version must be <= 32767." }}
{{- end }}
{{- if (.Values.bifrost.plugins.splunk).enabled }}
{{- $splunkInputConfig := .Values.bifrost.plugins.splunk.config | default dict }}
{{- if not $splunkInputConfig.endpoint }}
{{- fail "ERROR: bifrost.plugins.splunk.config.endpoint is required when the Splunk plugin is enabled." }}
{{- end }}
{{- if not $splunkInputConfig.token }}
{{- fail "ERROR: bifrost.plugins.splunk.config.token is required when the Splunk plugin is enabled." }}
{{- end }}
{{- $splunkEventsEnabled := true }}
{{- if hasKey $splunkInputConfig "enable_events" }}{{- $splunkEventsEnabled = $splunkInputConfig.enable_events }}{{- end }}
{{- if and $splunkEventsEnabled (not $splunkInputConfig.events_index) }}
{{- fail "ERROR: bifrost.plugins.splunk.config.events_index is required when the Splunk plugin has events enabled." }}
{{- end }}
{{- $splunkMetricsEnabled := true }}
{{- if hasKey $splunkInputConfig "enable_metrics" }}{{- $splunkMetricsEnabled = $splunkInputConfig.enable_metrics }}{{- end }}
{{- if and $splunkMetricsEnabled (not $splunkInputConfig.metrics_index) }}
{{- fail "ERROR: bifrost.plugins.splunk.config.metrics_index is required when the Splunk plugin has metrics enabled." }}
{{- end }}
{{- end }}

{{/* Validate semantic cache plugin when enabled */}}
{{- if .Values.bifrost.plugins.semanticCache.enabled }}
{{/* When dimension is 1, direct (hash-based) caching is used — provider and keys are not required. */}}
{{- if ne (int .Values.bifrost.plugins.semanticCache.config.dimension) 1 }}
{{- if not .Values.bifrost.plugins.semanticCache.config.provider }}
{{- fail "ERROR: bifrost.plugins.semanticCache.config.provider is required for semantic caching. Supported providers: openai, anthropic, gemini, bedrock, azure, cohere, mistral, groq, ollama, openrouter, vertex, cerebras, parasail, perplexity, sgl, huggingface, cloudflare. The provider's API keys are inherited from bifrost.providers, so configure that provider there. For direct (hash-based) caching, set dimension: 1." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate OTEL plugin when enabled */}}
{{- if .Values.bifrost.plugins.otel.enabled }}
{{- $otelInputConfig := .Values.bifrost.plugins.otel.config | default dict }}
{{- if hasKey $otelInputConfig "profiles" }}
{{- if not $otelInputConfig.profiles }}
{{- fail "ERROR: bifrost.plugins.otel.config.profiles must contain at least one profile when OTEL plugin is enabled." }}
{{- end }}
{{- range $idx, $profile := $otelInputConfig.profiles }}
{{- $profileEnabled := true }}
{{- if hasKey $profile "enabled" }}
{{- $profileEnabled = $profile.enabled }}
{{- end }}
{{- if $profileEnabled }}
{{- $tracesEnabled := true }}
{{- if hasKey $profile "traces_enabled" }}
{{- $tracesEnabled = $profile.traces_enabled }}
{{- end }}
{{- if $tracesEnabled }}
{{- if not $profile.collector_url }}
{{- fail (printf "ERROR: bifrost.plugins.otel.config.profiles[%d].collector_url is required when traces_enabled is true." $idx) }}
{{- end }}
{{- if not $profile.trace_type }}
{{- fail (printf "ERROR: bifrost.plugins.otel.config.profiles[%d].trace_type is required when traces_enabled is true. Supported values: genai_extension, vercel, open_inference" $idx) }}
{{- end }}
{{- end }}
{{- if and (or $tracesEnabled $profile.metrics_enabled) (not $profile.protocol) }}
{{- fail (printf "ERROR: bifrost.plugins.otel.config.profiles[%d].protocol is required. Supported values: http, grpc" $idx) }}
{{- end }}
{{- if and $profile.metrics_enabled (not $profile.metrics_endpoint) }}
{{- fail (printf "ERROR: bifrost.plugins.otel.config.profiles[%d].metrics_endpoint is required when metrics_enabled is true." $idx) }}
{{- end }}
{{- end }}
{{- end }}
{{- else }}
{{- $tracesEnabled := true }}
{{- if hasKey $otelInputConfig "traces_enabled" }}
{{- $tracesEnabled = $otelInputConfig.traces_enabled }}
{{- end }}
{{- if $tracesEnabled }}
{{- if not $otelInputConfig.collector_url }}
{{- fail "ERROR: bifrost.plugins.otel.config.collector_url is required when traces_enabled is true. Provide the URL of your OpenTelemetry collector." }}
{{- end }}
{{- if not $otelInputConfig.trace_type }}
{{- fail "ERROR: bifrost.plugins.otel.config.trace_type is required when traces_enabled is true. Supported values: genai_extension, vercel, open_inference" }}
{{- end }}
{{- end }}
{{- if and (or $tracesEnabled $otelInputConfig.metrics_enabled) (not $otelInputConfig.protocol) }}
{{- fail "ERROR: bifrost.plugins.otel.config.protocol is required. Supported values: http, grpc" }}
{{- end }}
{{- if and $otelInputConfig.metrics_enabled (not $otelInputConfig.metrics_endpoint) }}
{{- fail "ERROR: bifrost.plugins.otel.config.metrics_endpoint is required when metrics_enabled is true." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate Maxim plugin when enabled */}}
{{- if .Values.bifrost.plugins.maxim.enabled }}
{{- if and (not .Values.bifrost.plugins.maxim.config.api_key) (not .Values.bifrost.plugins.maxim.secretRef.name) }}
{{- fail "ERROR: bifrost.plugins.maxim.config.api_key or bifrost.plugins.maxim.secretRef.name is required when Maxim plugin is enabled." }}
{{- end }}
{{- end }}

{{/* Validate SCIM/SSO config when enabled */}}
{{- $scimValidation := .Values.bifrost.scim }}
{{- if and $scimValidation $scimValidation.enabled }}
{{- /* bifrost.scim has no chart default, so provider/config may be absent entirely — normalize
       before comparing/indexing or the template dies on a nil rather than failing with the
       actionable message below. */ -}}
{{- $scimProvider := default "" $scimValidation.provider }}
{{- $scimCfg := default dict $scimValidation.config }}
{{- if eq $scimProvider "okta" }}
{{- if not $scimCfg.issuerUrl }}
{{- fail "ERROR: bifrost.scim.config.issuerUrl is required when SCIM provider is Okta. Example: https://your-domain.okta.com/oauth2/default" }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is Okta." }}
{{- end }}
{{- if not $scimCfg.clientSecret }}
{{- fail "ERROR: bifrost.scim.config.clientSecret is required when SCIM provider is Okta." }}
{{- end }}
{{- end }}
{{- if eq $scimProvider "entra" }}
{{- if not $scimCfg.tenantId }}
{{- fail "ERROR: bifrost.scim.config.tenantId is required when SCIM provider is Entra (Azure AD)." }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is Entra (Azure AD)." }}
{{- end }}
{{- end }}
{{- if eq $scimProvider "keycloak" }}
{{- if not $scimCfg.serverUrl }}
{{- fail "ERROR: bifrost.scim.config.serverUrl is required when SCIM provider is Keycloak. Example: https://keycloak.company.com (must NOT include /realms/{realm})." }}
{{- end }}
{{- if not $scimCfg.realm }}
{{- fail "ERROR: bifrost.scim.config.realm is required when SCIM provider is Keycloak." }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is Keycloak." }}
{{- end }}
{{- if not $scimCfg.clientSecret }}
{{- fail "ERROR: bifrost.scim.config.clientSecret is required when SCIM provider is Keycloak." }}
{{- end }}
{{- end }}
{{- if eq $scimProvider "zitadel" }}
{{- if not $scimCfg.domain }}
{{- fail "ERROR: bifrost.scim.config.domain is required when SCIM provider is Zitadel. Example: my-instance.zitadel.cloud (no scheme)." }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is Zitadel." }}
{{- end }}
{{- end }}
{{- if eq $scimProvider "google" }}
{{- if not $scimCfg.domain }}
{{- fail "ERROR: bifrost.scim.config.domain is required when SCIM provider is Google Workspace. Example: company.com" }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is Google Workspace." }}
{{- end }}
{{- end }}
{{- if eq $scimProvider "generic" }}
{{- if not $scimCfg.issuerUrl }}
{{- fail "ERROR: bifrost.scim.config.issuerUrl is required when SCIM provider is a generic OIDC provider. Example: https://idp.company.com" }}
{{- end }}
{{- if not $scimCfg.clientId }}
{{- fail "ERROR: bifrost.scim.config.clientId is required when SCIM provider is a generic OIDC provider." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate cluster config when enabled */}}
{{- if and .Values.bifrost.cluster .Values.bifrost.cluster.enabled }}
{{- if not .Values.bifrost.cluster.gossip }}
{{- fail "ERROR: bifrost.cluster.gossip is required when cluster mode is enabled." }}
{{- end }}
{{- if not .Values.bifrost.cluster.gossip.port }}
{{- fail "ERROR: bifrost.cluster.gossip.port is required when cluster mode is enabled." }}
{{- end }}
{{- if not .Values.bifrost.cluster.gossip.config }}
{{- fail "ERROR: bifrost.cluster.gossip.config is required when cluster mode is enabled." }}
{{- end }}
{{- if not .Values.bifrost.cluster.gossip.config.timeoutSeconds }}
{{- fail "ERROR: bifrost.cluster.gossip.config.timeoutSeconds is required when cluster mode is enabled." }}
{{- end }}
{{- if not .Values.bifrost.cluster.gossip.config.successThreshold }}
{{- fail "ERROR: bifrost.cluster.gossip.config.successThreshold is required when cluster mode is enabled." }}
{{- end }}
{{- if not .Values.bifrost.cluster.gossip.config.failureThreshold }}
{{- fail "ERROR: bifrost.cluster.gossip.config.failureThreshold is required when cluster mode is enabled." }}
{{- end }}
{{- if and .Values.bifrost.cluster.discovery .Values.bifrost.cluster.discovery.enabled }}
{{- if not .Values.bifrost.cluster.discovery.type }}
{{- fail "ERROR: bifrost.cluster.discovery.type is required when cluster discovery is enabled. Supported types: kubernetes, dns, udp, consul, etcd, mdns" }}
{{- end }}
{{- if eq .Values.bifrost.cluster.discovery.type "udp" }}
{{- if not .Values.bifrost.cluster.discovery.udpBroadcastPort }}
{{- fail "ERROR: bifrost.cluster.discovery.udpBroadcastPort is required when using udp discovery." }}
{{- end }}
{{- if not .Values.bifrost.cluster.discovery.allowedAddressSpace }}
{{- fail "ERROR: bifrost.cluster.discovery.allowedAddressSpace is required when using udp discovery." }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate RBAC pod discovery + service account configuration */}}
{{- if and .Values.rbac .Values.rbac.podDiscovery .Values.rbac.podDiscovery.enabled }}
{{- if and .Values.bifrost.cluster.enabled .Values.bifrost.cluster.discovery.enabled (eq .Values.bifrost.cluster.discovery.type "kubernetes") }}
{{- if and (not .Values.serviceAccount.create) (not .Values.serviceAccount.name) }}
{{- fail "ERROR: rbac.podDiscovery.enabled requires either serviceAccount.create=true or an explicit serviceAccount.name when serviceAccount.create=false." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate external Weaviate when vector store type is weaviate */}}
{{- if and .Values.vectorStore.enabled (eq .Values.vectorStore.type "weaviate") }}
{{- if .Values.vectorStore.weaviate.external.enabled }}
{{- if not .Values.vectorStore.weaviate.external.scheme }}
{{- fail "ERROR: vectorStore.weaviate.external.scheme is required when using external Weaviate. Values: http or https" }}
{{- end }}
{{- if not .Values.vectorStore.weaviate.external.host }}
{{- fail "ERROR: vectorStore.weaviate.external.host is required when using external Weaviate." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate external Redis when vector store type is redis */}}
{{- if and .Values.vectorStore.enabled (eq .Values.vectorStore.type "redis") }}
{{- if .Values.vectorStore.redis.external.enabled }}
{{- if not .Values.vectorStore.redis.external.host }}
{{- fail "ERROR: vectorStore.redis.external.host is required when using external Redis." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate external Qdrant when vector store type is qdrant */}}
{{- if and .Values.vectorStore.enabled (eq .Values.vectorStore.type "qdrant") }}
{{- if .Values.vectorStore.qdrant.external.enabled }}
{{- if not .Values.vectorStore.qdrant.external.host }}
{{- fail "ERROR: vectorStore.qdrant.external.host is required when using external Qdrant." }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate external PostgreSQL when enabled */}}
{{- if .Values.postgresql.external.enabled }}
{{- if not .Values.postgresql.external.host }}
{{- fail "ERROR: postgresql.external.host is required when using external PostgreSQL." }}
{{- end }}
{{- if not .Values.postgresql.external.database }}
{{- fail "ERROR: postgresql.external.database is required when using external PostgreSQL." }}
{{- end }}
{{- if not .Values.postgresql.external.user }}
{{- fail "ERROR: postgresql.external.user is required when using external PostgreSQL." }}
{{- end }}
{{- if not .Values.postgresql.external.sslMode }}
{{- fail "ERROR: postgresql.external.sslMode is required when using external PostgreSQL. Values: disable, allow, prefer, require, verify-ca, verify-full" }}
{{- end }}
{{- end }}

{{/* Validate governance budgets */}}
{{- if .Values.bifrost.governance.budgets }}
{{- range $idx, $budget := .Values.bifrost.governance.budgets }}
{{- if not $budget.id }}
{{- fail (printf "ERROR: bifrost.governance.budgets[%d].id is required." $idx) }}
{{- end }}
{{- if not $budget.max_limit }}
{{- fail (printf "ERROR: bifrost.governance.budgets[%d].max_limit is required for budget '%s'." $idx $budget.id) }}
{{- end }}
{{- if not $budget.reset_duration }}
{{- fail (printf "ERROR: bifrost.governance.budgets[%d].reset_duration is required for budget '%s'. Example values: 30s, 5m, 1h, 1d, 1w, 1M, 1Y" $idx $budget.id) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance rate limits */}}
{{- if .Values.bifrost.governance.rateLimits }}
{{- range $idx, $rl := .Values.bifrost.governance.rateLimits }}
{{- if not $rl.id }}
{{- fail (printf "ERROR: bifrost.governance.rateLimits[%d].id is required." $idx) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance customers */}}
{{- if .Values.bifrost.governance.customers }}
{{- range $idx, $customer := .Values.bifrost.governance.customers }}
{{- if not $customer.id }}
{{- fail (printf "ERROR: bifrost.governance.customers[%d].id is required." $idx) }}
{{- end }}
{{- if not $customer.name }}
{{- fail (printf "ERROR: bifrost.governance.customers[%d].name is required for customer '%s'." $idx $customer.id) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance teams */}}
{{- if .Values.bifrost.governance.teams }}
{{- range $idx, $team := .Values.bifrost.governance.teams }}
{{- if not $team.id }}
{{- fail (printf "ERROR: bifrost.governance.teams[%d].id is required." $idx) }}
{{- end }}
{{- if not $team.name }}
{{- fail (printf "ERROR: bifrost.governance.teams[%d].name is required for team '%s'." $idx $team.id) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance business units */}}
{{- if .Values.bifrost.governance.businessUnits }}
{{- range $idx, $bu := .Values.bifrost.governance.businessUnits }}
{{- if not $bu.id }}
{{- fail (printf "ERROR: bifrost.governance.businessUnits[%d].id is required." $idx) }}
{{- end }}
{{- if not $bu.name }}
{{- fail (printf "ERROR: bifrost.governance.businessUnits[%d].name is required for business unit '%s'." $idx $bu.id) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance virtual keys */}}
{{- if .Values.bifrost.governance.virtualKeys }}
{{- range $idx, $vk := .Values.bifrost.governance.virtualKeys }}
{{- if not $vk.id }}
{{- fail (printf "ERROR: bifrost.governance.virtualKeys[%d].id is required." $idx) }}
{{- end }}
{{- if not $vk.name }}
{{- fail (printf "ERROR: bifrost.governance.virtualKeys[%d].name is required for virtual key '%s'." $idx $vk.id) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate governance roles */}}
{{- if .Values.bifrost.governance.roles }}
{{- range $idx, $role := .Values.bifrost.governance.roles }}
{{- if not $role.name }}
{{- fail (printf "ERROR: bifrost.governance.roles[%d].name is required." $idx) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate guardrails rules */}}
{{- if .Values.bifrost.guardrails.rules }}
{{- range $idx, $rule := .Values.bifrost.guardrails.rules }}
{{- if not $rule.id }}
{{- fail (printf "ERROR: bifrost.guardrails.rules[%d].id is required." $idx) }}
{{- end }}
{{- if not $rule.name }}
{{- fail (printf "ERROR: bifrost.guardrails.rules[%d].name is required for rule id '%v'." $idx $rule.id) }}
{{- end }}
{{- if not (hasKey $rule "enabled") }}
{{- fail (printf "ERROR: bifrost.guardrails.rules[%d].enabled is required for rule '%s'." $idx $rule.name) }}
{{- end }}
{{- if not $rule.cel_expression }}
{{- fail (printf "ERROR: bifrost.guardrails.rules[%d].cel_expression is required for rule '%s'." $idx $rule.name) }}
{{- end }}
{{- if not $rule.apply_to }}
{{- fail (printf "ERROR: bifrost.guardrails.rules[%d].apply_to is required for rule '%s'. Values: input, output, both" $idx $rule.name) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate guardrails providers */}}
{{- if .Values.bifrost.guardrails.providers }}
{{- range $idx, $provider := .Values.bifrost.guardrails.providers }}
{{- if not $provider.id }}
{{- fail (printf "ERROR: bifrost.guardrails.providers[%d].id is required." $idx) }}
{{- end }}
{{- if not $provider.provider_name }}
{{- fail (printf "ERROR: bifrost.guardrails.providers[%d].provider_name is required for provider id '%v'." $idx $provider.id) }}
{{- end }}
{{- if not $provider.policy_name }}
{{- fail (printf "ERROR: bifrost.guardrails.providers[%d].policy_name is required for provider '%s'." $idx $provider.provider_name) }}
{{- end }}
{{- if not (hasKey $provider "enabled") }}
{{- fail (printf "ERROR: bifrost.guardrails.providers[%d].enabled is required for provider '%s'." $idx $provider.provider_name) }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate MCP client configs when MCP is enabled */}}
{{- if .Values.bifrost.mcp.enabled }}
{{- if .Values.bifrost.mcp.clientConfigs }}
{{- range $idx, $client := .Values.bifrost.mcp.clientConfigs }}
{{- if not $client.name }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].name is required." $idx) }}
{{- end }}
{{- if not $client.connectionType }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].connectionType is required for client '%s'. Values: stdio, websocket, http" $idx $client.name) }}
{{- end }}
{{- if eq $client.connectionType "stdio" }}
{{- if not $client.stdioConfig }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].stdioConfig is required when connectionType is 'stdio' for client '%s'." $idx $client.name) }}
{{- end }}
{{- if not $client.stdioConfig.command }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].stdioConfig.command is required for client '%s'." $idx $client.name) }}
{{- end }}
{{- end }}
{{- if eq $client.connectionType "websocket" }}
{{- if not $client.websocketConfig }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].websocketConfig is required when connectionType is 'websocket' for client '%s'." $idx $client.name) }}
{{- end }}
{{- if not $client.websocketConfig.url }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].websocketConfig.url is required for client '%s'." $idx $client.name) }}
{{- end }}
{{- end }}
{{- if eq $client.connectionType "http" }}
{{- if not $client.httpConfig }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].httpConfig is required when connectionType is 'http' for client '%s'." $idx $client.name) }}
{{- end }}
{{- if not $client.httpConfig.url }}
{{- fail (printf "ERROR: bifrost.mcp.clientConfigs[%d].httpConfig.url is required for client '%s'." $idx $client.name) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- if .Values.bifrost.mcp.toolGroups }}
{{- range $idx, $group := .Values.bifrost.mcp.toolGroups }}
{{- if not (trim (default "" $group.name)) }}
{{- fail (printf "ERROR: bifrost.mcp.toolGroups[%d].name is required." $idx) }}
{{- end }}
{{- if not $group.tools }}
{{- fail (printf "ERROR: bifrost.mcp.toolGroups[%d].tools is required for group '%s'." $idx $group.name) }}
{{- end }}
{{- end }}
{{- end }}
{{- if .Values.bifrost.mcp.virtualMcps }}
{{- range $idx, $vmcp := .Values.bifrost.mcp.virtualMcps }}
{{- if not (trim (default "" $vmcp.name)) }}
{{- fail (printf "ERROR: bifrost.mcp.virtualMcps[%d].name is required." $idx) }}
{{- end }}
{{- if not $vmcp.tools }}
{{- fail (printf "ERROR: bifrost.mcp.virtualMcps[%d].tools is required for Virtual MCP '%s'." $idx $vmcp.name) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/* Validate custom plugins */}}
{{- if .Values.bifrost.plugins.custom }}
{{- range $idx, $plugin := .Values.bifrost.plugins.custom }}
{{- if not $plugin.name }}
{{- fail (printf "ERROR: bifrost.plugins.custom[%d].name is required." $idx) }}
{{- end }}
{{- if not (hasKey $plugin "enabled") }}
{{- fail (printf "ERROR: bifrost.plugins.custom[%d].enabled is required for plugin '%s'." $idx $plugin.name) }}
{{- end }}
{{- if and (hasKey $plugin "version") (lt (int $plugin.version) 1) }}
{{- fail (printf "ERROR: bifrost.plugins.custom[%d].version must be >= 1 for plugin '%s'." $idx $plugin.name) }}
{{- end }}
{{- if and (hasKey $plugin "version") (gt (int $plugin.version) 32767) }}
{{- fail (printf "ERROR: bifrost.plugins.custom[%d].version must be <= 32767 for plugin '%s'." $idx $plugin.name) }}
{{- end }}
{{- end }}
{{- end }}

{{- end -}}